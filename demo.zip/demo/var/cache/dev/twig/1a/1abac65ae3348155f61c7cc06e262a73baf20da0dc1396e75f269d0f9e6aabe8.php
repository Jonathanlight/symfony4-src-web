<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_a86ce6b0d9b565d7e369ce50b7f954557935f89724ec1359e8c5494508c591ca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_df95f97954576f957fbaee43f3d8f7ce48bbac2b1634f2f62827bdfb0297532d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_df95f97954576f957fbaee43f3d8f7ce48bbac2b1634f2f62827bdfb0297532d->enter($__internal_df95f97954576f957fbaee43f3d8f7ce48bbac2b1634f2f62827bdfb0297532d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_6c32229a4d6d28f6f34dfd7b1c03a8bfdfabb4b16557bdc93e9effb9219aed2a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c32229a4d6d28f6f34dfd7b1c03a8bfdfabb4b16557bdc93e9effb9219aed2a->enter($__internal_6c32229a4d6d28f6f34dfd7b1c03a8bfdfabb4b16557bdc93e9effb9219aed2a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_df95f97954576f957fbaee43f3d8f7ce48bbac2b1634f2f62827bdfb0297532d->leave($__internal_df95f97954576f957fbaee43f3d8f7ce48bbac2b1634f2f62827bdfb0297532d_prof);

        
        $__internal_6c32229a4d6d28f6f34dfd7b1c03a8bfdfabb4b16557bdc93e9effb9219aed2a->leave($__internal_6c32229a4d6d28f6f34dfd7b1c03a8bfdfabb4b16557bdc93e9effb9219aed2a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/button_label.html.php");
    }
}
