<?php

/* @Twig/Exception/exception.rdf.twig */
class __TwigTemplate_2a72b2940fa4a58854d5fcea4178a7f27142c8e31c9c98ae573e2659061ee025 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_25215f5dc8950401240e612fb3fc436d657c919a2522289363a2eda832dfb773 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_25215f5dc8950401240e612fb3fc436d657c919a2522289363a2eda832dfb773->enter($__internal_25215f5dc8950401240e612fb3fc436d657c919a2522289363a2eda832dfb773_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        $__internal_7c5978d414167815e0a24073c7b8e60ad839f7081a86e1c2558da5fbf0721e07 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c5978d414167815e0a24073c7b8e60ad839f7081a86e1c2558da5fbf0721e07->enter($__internal_7c5978d414167815e0a24073c7b8e60ad839f7081a86e1c2558da5fbf0721e07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 1, $this->getSourceContext()); })())));
        echo "
";
        
        $__internal_25215f5dc8950401240e612fb3fc436d657c919a2522289363a2eda832dfb773->leave($__internal_25215f5dc8950401240e612fb3fc436d657c919a2522289363a2eda832dfb773_prof);

        
        $__internal_7c5978d414167815e0a24073c7b8e60ad839f7081a86e1c2558da5fbf0721e07->leave($__internal_7c5978d414167815e0a24073c7b8e60ad839f7081a86e1c2558da5fbf0721e07_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "@Twig/Exception/exception.rdf.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/twig-bundle/Resources/views/Exception/exception.rdf.twig");
    }
}
