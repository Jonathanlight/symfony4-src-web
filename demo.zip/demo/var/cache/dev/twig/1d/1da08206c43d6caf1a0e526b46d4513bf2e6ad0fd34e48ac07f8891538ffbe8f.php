<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_a0d0cd61bdcc0fbeade0276db6a16cc5930c7a2facf320f07d8b21eb218cd785 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e4a65a2ab20e7debb62e0a211543cc1c2895126657bcdae6f03b7769e32a55b1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e4a65a2ab20e7debb62e0a211543cc1c2895126657bcdae6f03b7769e32a55b1->enter($__internal_e4a65a2ab20e7debb62e0a211543cc1c2895126657bcdae6f03b7769e32a55b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        $__internal_b28c5dfe58b77c6fb748e77491d9c51950fee6eab37ea0e5104a02da549a3412 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b28c5dfe58b77c6fb748e77491d9c51950fee6eab37ea0e5104a02da549a3412->enter($__internal_b28c5dfe58b77c6fb748e77491d9c51950fee6eab37ea0e5104a02da549a3412_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_e4a65a2ab20e7debb62e0a211543cc1c2895126657bcdae6f03b7769e32a55b1->leave($__internal_e4a65a2ab20e7debb62e0a211543cc1c2895126657bcdae6f03b7769e32a55b1_prof);

        
        $__internal_b28c5dfe58b77c6fb748e77491d9c51950fee6eab37ea0e5104a02da549a3412->leave($__internal_b28c5dfe58b77c6fb748e77491d9c51950fee6eab37ea0e5104a02da549a3412_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
", "@Framework/Form/integer_widget.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/integer_widget.html.php");
    }
}
