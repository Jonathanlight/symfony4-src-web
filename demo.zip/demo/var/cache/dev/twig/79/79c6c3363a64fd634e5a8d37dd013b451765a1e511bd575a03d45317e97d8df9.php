<?php

/* @WebProfiler/Profiler/header.html.twig */
class __TwigTemplate_5fdbc9602ceb8168b4a429055c3ed72d105b59ac8372de1027b957d3ea9915ba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_af35441b7f2b2b2fc02a7ec9508200ebb5ca0b49526f28287c1228d37c1d4f6f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_af35441b7f2b2b2fc02a7ec9508200ebb5ca0b49526f28287c1228d37c1d4f6f->enter($__internal_af35441b7f2b2b2fc02a7ec9508200ebb5ca0b49526f28287c1228d37c1d4f6f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/header.html.twig"));

        $__internal_81a1766bd80ab6cb183adf8ee13bf87a64135b83bdb1bb7050001559e0eadbe0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_81a1766bd80ab6cb183adf8ee13bf87a64135b83bdb1bb7050001559e0eadbe0->enter($__internal_81a1766bd80ab6cb183adf8ee13bf87a64135b83bdb1bb7050001559e0eadbe0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/header.html.twig"));

        // line 1
        echo "<div id=\"header\">
    <div class=\"container\">
        <h1>";
        // line 3
        echo twig_include($this->env, $context, "@WebProfiler/Icon/symfony.svg");
        echo " Symfony <span>Profiler</span></h1>

        <div class=\"search\">
            <form method=\"get\" action=\"https://symfony.com/search\" target=\"_blank\">
                <div class=\"form-row\">
                    <input name=\"q\" id=\"search-id\" type=\"search\" placeholder=\"search on symfony.com\">
                    <button type=\"submit\" class=\"btn\">Search</button>
                </div>
           </form>
        </div>
    </div>
</div>
";
        
        $__internal_af35441b7f2b2b2fc02a7ec9508200ebb5ca0b49526f28287c1228d37c1d4f6f->leave($__internal_af35441b7f2b2b2fc02a7ec9508200ebb5ca0b49526f28287c1228d37c1d4f6f_prof);

        
        $__internal_81a1766bd80ab6cb183adf8ee13bf87a64135b83bdb1bb7050001559e0eadbe0->leave($__internal_81a1766bd80ab6cb183adf8ee13bf87a64135b83bdb1bb7050001559e0eadbe0_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  29 => 3,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div id=\"header\">
    <div class=\"container\">
        <h1>{{ include('@WebProfiler/Icon/symfony.svg') }} Symfony <span>Profiler</span></h1>

        <div class=\"search\">
            <form method=\"get\" action=\"https://symfony.com/search\" target=\"_blank\">
                <div class=\"form-row\">
                    <input name=\"q\" id=\"search-id\" type=\"search\" placeholder=\"search on symfony.com\">
                    <button type=\"submit\" class=\"btn\">Search</button>
                </div>
           </form>
        </div>
    </div>
</div>
", "@WebProfiler/Profiler/header.html.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/web-profiler-bundle/Resources/views/Profiler/header.html.twig");
    }
}
