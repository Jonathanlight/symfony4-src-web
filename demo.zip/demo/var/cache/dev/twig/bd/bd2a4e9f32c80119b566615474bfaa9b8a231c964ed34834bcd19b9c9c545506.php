<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_4d734f8edbca2978adb108aa871d9431b7fa78d008b4501b0adcdea3a6e56f40 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_90dd4474bf54c9f035b742a29dc11a069248b3e14d766d92fa38e834f80eb6fd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_90dd4474bf54c9f035b742a29dc11a069248b3e14d766d92fa38e834f80eb6fd->enter($__internal_90dd4474bf54c9f035b742a29dc11a069248b3e14d766d92fa38e834f80eb6fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        $__internal_71b3458524af9b3ffee7a931037d7b0b6f8a247097d64c7044be1a7cd0357fcb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_71b3458524af9b3ffee7a931037d7b0b6f8a247097d64c7044be1a7cd0357fcb->enter($__internal_71b3458524af9b3ffee7a931037d7b0b6f8a247097d64c7044be1a7cd0357fcb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_90dd4474bf54c9f035b742a29dc11a069248b3e14d766d92fa38e834f80eb6fd->leave($__internal_90dd4474bf54c9f035b742a29dc11a069248b3e14d766d92fa38e834f80eb6fd_prof);

        
        $__internal_71b3458524af9b3ffee7a931037d7b0b6f8a247097d64c7044be1a7cd0357fcb->leave($__internal_71b3458524af9b3ffee7a931037d7b0b6f8a247097d64c7044be1a7cd0357fcb_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
", "@Framework/Form/form_widget.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/form_widget.html.php");
    }
}
