<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_687a448468d4c2d2c7733552b4ab100e93593808b7676db8ab0f79143a3e7195 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_23d4d86b6a3426739890474e87879c546ec52010f65cf9b6f60d6b91bd5a0c9c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_23d4d86b6a3426739890474e87879c546ec52010f65cf9b6f60d6b91bd5a0c9c->enter($__internal_23d4d86b6a3426739890474e87879c546ec52010f65cf9b6f60d6b91bd5a0c9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        $__internal_3ec0ed774f01e45590b8509ec8d44a263ac622a47e778387fd407b32dd38730f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3ec0ed774f01e45590b8509ec8d44a263ac622a47e778387fd407b32dd38730f->enter($__internal_3ec0ed774f01e45590b8509ec8d44a263ac622a47e778387fd407b32dd38730f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
";
        
        $__internal_23d4d86b6a3426739890474e87879c546ec52010f65cf9b6f60d6b91bd5a0c9c->leave($__internal_23d4d86b6a3426739890474e87879c546ec52010f65cf9b6f60d6b91bd5a0c9c_prof);

        
        $__internal_3ec0ed774f01e45590b8509ec8d44a263ac622a47e778387fd407b32dd38730f->leave($__internal_3ec0ed774f01e45590b8509ec8d44a263ac622a47e778387fd407b32dd38730f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
", "@Framework/FormTable/hidden_row.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/FormTable/hidden_row.html.php");
    }
}
