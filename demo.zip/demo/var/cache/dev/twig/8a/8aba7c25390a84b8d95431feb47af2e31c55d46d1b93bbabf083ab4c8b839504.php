<?php

/* page/home.html.twig */
class __TwigTemplate_6348b8c95195f6f9ff1dca19e571a33a5a788d1b2ce4e77dffe7b489113510dc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "page/home.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2708d62cc678a97089952600d6dd127ffcf1873c181d64ee49a6301fe5b433be = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2708d62cc678a97089952600d6dd127ffcf1873c181d64ee49a6301fe5b433be->enter($__internal_2708d62cc678a97089952600d6dd127ffcf1873c181d64ee49a6301fe5b433be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "page/home.html.twig"));

        $__internal_09f05dd35b59bf8ed22fe79dbf8bd8225d45c759722210b1224e3971af9e492c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_09f05dd35b59bf8ed22fe79dbf8bd8225d45c759722210b1224e3971af9e492c->enter($__internal_09f05dd35b59bf8ed22fe79dbf8bd8225d45c759722210b1224e3971af9e492c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "page/home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2708d62cc678a97089952600d6dd127ffcf1873c181d64ee49a6301fe5b433be->leave($__internal_2708d62cc678a97089952600d6dd127ffcf1873c181d64ee49a6301fe5b433be_prof);

        
        $__internal_09f05dd35b59bf8ed22fe79dbf8bd8225d45c759722210b1224e3971af9e492c->leave($__internal_09f05dd35b59bf8ed22fe79dbf8bd8225d45c759722210b1224e3971af9e492c_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_fb5de1730c40d2071249b2522a799dc4b76b1a284c357a806befde89f562004b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fb5de1730c40d2071249b2522a799dc4b76b1a284c357a806befde89f562004b->enter($__internal_fb5de1730c40d2071249b2522a799dc4b76b1a284c357a806befde89f562004b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_b42e0c31927bf62c337594df8152a136c9b6c0ce19195936700b8cd25815d14a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b42e0c31927bf62c337594df8152a136c9b6c0ce19195936700b8cd25815d14a->enter($__internal_b42e0c31927bf62c337594df8152a136c9b6c0ce19195936700b8cd25815d14a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
<div class=\"container\">

    <div class=\"starter-template\">
        <h1>List Product</h1>
    </div>

    <ul class=\"list-group\">
        ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reponses"]) || array_key_exists("reponses", $context) ? $context["reponses"] : (function () { throw new Twig_Error_Runtime('Variable "reponses" does not exist.', 12, $this->getSourceContext()); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["reponse"]) {
            // line 13
            echo "            <li class=\"list-group-item\"> ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["reponse"], "name", array()), "html", null, true);
            echo " | ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["reponse"], "price", array()), "html", null, true);
            echo " euro </li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['reponse'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "    </ul>

</div>
";
        
        $__internal_b42e0c31927bf62c337594df8152a136c9b6c0ce19195936700b8cd25815d14a->leave($__internal_b42e0c31927bf62c337594df8152a136c9b6c0ce19195936700b8cd25815d14a_prof);

        
        $__internal_fb5de1730c40d2071249b2522a799dc4b76b1a284c357a806befde89f562004b->leave($__internal_fb5de1730c40d2071249b2522a799dc4b76b1a284c357a806befde89f562004b_prof);

    }

    public function getTemplateName()
    {
        return "page/home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 15,  65 => 13,  61 => 12,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    {{ parent() }}
<div class=\"container\">

    <div class=\"starter-template\">
        <h1>List Product</h1>
    </div>

    <ul class=\"list-group\">
        {% for reponse in reponses %}
            <li class=\"list-group-item\"> {{ reponse.name }} | {{ reponse.price }} euro </li>
        {% endfor %}
    </ul>

</div>
{% endblock %}


", "page/home.html.twig", "/Users/admin/Desktop/Work/Jonathan/demo/src/Resources/views/page/home.html.twig");
    }
}
