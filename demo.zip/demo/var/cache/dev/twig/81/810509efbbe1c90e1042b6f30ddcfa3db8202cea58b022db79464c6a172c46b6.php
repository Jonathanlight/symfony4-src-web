<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_3bdad2ac27816117fd14b91bfb4192726db1e8c458dbb3dab49be20ea7846fc7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9b800d8d7a6072e033c720f11e7ca460c96c633d1b1d229a6c3b91b33348a0fd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9b800d8d7a6072e033c720f11e7ca460c96c633d1b1d229a6c3b91b33348a0fd->enter($__internal_9b800d8d7a6072e033c720f11e7ca460c96c633d1b1d229a6c3b91b33348a0fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        $__internal_a6e93cfb7d6a9803fbaf3ccfbf9bb5a16f009960e54c46ebdbfead670aba121d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a6e93cfb7d6a9803fbaf3ccfbf9bb5a16f009960e54c46ebdbfead670aba121d->enter($__internal_a6e93cfb7d6a9803fbaf3ccfbf9bb5a16f009960e54c46ebdbfead670aba121d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_9b800d8d7a6072e033c720f11e7ca460c96c633d1b1d229a6c3b91b33348a0fd->leave($__internal_9b800d8d7a6072e033c720f11e7ca460c96c633d1b1d229a6c3b91b33348a0fd_prof);

        
        $__internal_a6e93cfb7d6a9803fbaf3ccfbf9bb5a16f009960e54c46ebdbfead670aba121d->leave($__internal_a6e93cfb7d6a9803fbaf3ccfbf9bb5a16f009960e54c46ebdbfead670aba121d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/checkbox_widget.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/checkbox_widget.html.php");
    }
}
