<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_dc2ba83d0fb4680e2db3fbb3856235fc1d06f866142d0211fef977b3f2d23f54 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9b96c9a29e6b3e5bdd722480e7fdb8b248d62016d91df8d7aa8553d94731f677 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9b96c9a29e6b3e5bdd722480e7fdb8b248d62016d91df8d7aa8553d94731f677->enter($__internal_9b96c9a29e6b3e5bdd722480e7fdb8b248d62016d91df8d7aa8553d94731f677_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_c8eab7508b4a5c67bfa20181d5c061ba717cb1c066b12a40f894c29c2fa0a69a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c8eab7508b4a5c67bfa20181d5c061ba717cb1c066b12a40f894c29c2fa0a69a->enter($__internal_c8eab7508b4a5c67bfa20181d5c061ba717cb1c066b12a40f894c29c2fa0a69a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_9b96c9a29e6b3e5bdd722480e7fdb8b248d62016d91df8d7aa8553d94731f677->leave($__internal_9b96c9a29e6b3e5bdd722480e7fdb8b248d62016d91df8d7aa8553d94731f677_prof);

        
        $__internal_c8eab7508b4a5c67bfa20181d5c061ba717cb1c066b12a40f894c29c2fa0a69a->leave($__internal_c8eab7508b4a5c67bfa20181d5c061ba717cb1c066b12a40f894c29c2fa0a69a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/hidden_row.html.php");
    }
}
