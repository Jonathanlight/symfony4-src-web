<?php

/* @WebProfiler/Collector/ajax.html.twig */
class __TwigTemplate_ac8be53ce97db23c12e5ced2cbf374c29ce125d263a2a784f2783aff2bedbf7f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/ajax.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9598db8623234583aa68233f999cab7f05c598720ec64a584f2c4967dfedf936 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9598db8623234583aa68233f999cab7f05c598720ec64a584f2c4967dfedf936->enter($__internal_9598db8623234583aa68233f999cab7f05c598720ec64a584f2c4967dfedf936_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/ajax.html.twig"));

        $__internal_216beb48f56d0befa4646407be8669bc2b6ac14225be99fe2caadefe0233275f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_216beb48f56d0befa4646407be8669bc2b6ac14225be99fe2caadefe0233275f->enter($__internal_216beb48f56d0befa4646407be8669bc2b6ac14225be99fe2caadefe0233275f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/ajax.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9598db8623234583aa68233f999cab7f05c598720ec64a584f2c4967dfedf936->leave($__internal_9598db8623234583aa68233f999cab7f05c598720ec64a584f2c4967dfedf936_prof);

        
        $__internal_216beb48f56d0befa4646407be8669bc2b6ac14225be99fe2caadefe0233275f->leave($__internal_216beb48f56d0befa4646407be8669bc2b6ac14225be99fe2caadefe0233275f_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_5b5b827f1ba2905cc4d0eba6b7446cc70b26c77d2be49900a6152dc886fb5d7c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5b5b827f1ba2905cc4d0eba6b7446cc70b26c77d2be49900a6152dc886fb5d7c->enter($__internal_5b5b827f1ba2905cc4d0eba6b7446cc70b26c77d2be49900a6152dc886fb5d7c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_aef9de59906c80ca6365e44f62d98c5622d91474ccb0c1856dc068ed064c7288 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aef9de59906c80ca6365e44f62d98c5622d91474ccb0c1856dc068ed064c7288->enter($__internal_aef9de59906c80ca6365e44f62d98c5622d91474ccb0c1856dc068ed064c7288_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        // line 4
        echo "    ";
        ob_start();
        // line 5
        echo "        ";
        echo twig_include($this->env, $context, "@WebProfiler/Icon/ajax.svg");
        echo "
        <span class=\"sf-toolbar-value sf-toolbar-ajax-request-counter\">0</span>
    ";
        $context["icon"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 8
        echo "
    ";
        // line 9
        $context["text"] = ('' === $tmp = "        <div class=\"sf-toolbar-info-piece\">
            <b class=\"sf-toolbar-ajax-info\"></b>
        </div>
        <div class=\"sf-toolbar-info-piece\">
            <table class=\"sf-toolbar-ajax-requests\">
                <thead>
                    <tr>
                        <th>Method</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>URL</th>
                        <th>Time</th>
                        <th>Profile</th>
                    </tr>
                </thead>
                <tbody class=\"sf-toolbar-ajax-request-list\"></tbody>
            </table>
        </div>
    ") ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 29
        echo "
    ";
        // line 30
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/toolbar_item.html.twig", array("link" => false));
        echo "
";
        
        $__internal_aef9de59906c80ca6365e44f62d98c5622d91474ccb0c1856dc068ed064c7288->leave($__internal_aef9de59906c80ca6365e44f62d98c5622d91474ccb0c1856dc068ed064c7288_prof);

        
        $__internal_5b5b827f1ba2905cc4d0eba6b7446cc70b26c77d2be49900a6152dc886fb5d7c->leave($__internal_5b5b827f1ba2905cc4d0eba6b7446cc70b26c77d2be49900a6152dc886fb5d7c_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/ajax.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 30,  82 => 29,  62 => 9,  59 => 8,  52 => 5,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}
    {% set icon %}
        {{ include('@WebProfiler/Icon/ajax.svg') }}
        <span class=\"sf-toolbar-value sf-toolbar-ajax-request-counter\">0</span>
    {% endset %}

    {% set text %}
        <div class=\"sf-toolbar-info-piece\">
            <b class=\"sf-toolbar-ajax-info\"></b>
        </div>
        <div class=\"sf-toolbar-info-piece\">
            <table class=\"sf-toolbar-ajax-requests\">
                <thead>
                    <tr>
                        <th>Method</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>URL</th>
                        <th>Time</th>
                        <th>Profile</th>
                    </tr>
                </thead>
                <tbody class=\"sf-toolbar-ajax-request-list\"></tbody>
            </table>
        </div>
    {% endset %}

    {{ include('@WebProfiler/Profiler/toolbar_item.html.twig', { link: false }) }}
{% endblock %}
", "@WebProfiler/Collector/ajax.html.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/web-profiler-bundle/Resources/views/Collector/ajax.html.twig");
    }
}
