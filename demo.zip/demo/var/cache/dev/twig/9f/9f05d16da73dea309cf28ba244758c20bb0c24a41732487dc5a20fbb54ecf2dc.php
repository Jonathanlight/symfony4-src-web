<?php

/* @Twig/images/icon-minus-square.svg */
class __TwigTemplate_681006cec18eece70079dfca22124bfb719429cd92483067a2d80240fba14ff4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dc6ca391c9a14ab7087f9d6f11053dd8b17b4b4862477f3cb0e4a432aeaf308c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dc6ca391c9a14ab7087f9d6f11053dd8b17b4b4862477f3cb0e4a432aeaf308c->enter($__internal_dc6ca391c9a14ab7087f9d6f11053dd8b17b4b4862477f3cb0e4a432aeaf308c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square.svg"));

        $__internal_83ca84e23e4041893a9969901b516df6c42598d7e03a1bc780addbc613c1be6c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_83ca84e23e4041893a9969901b516df6c42598d7e03a1bc780addbc613c1be6c->enter($__internal_83ca84e23e4041893a9969901b516df6c42598d7e03a1bc780addbc613c1be6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960V832q0-26-19-45t-45-19H448q-26 0-45 19t-19 45v128q0 26 19 45t45 19h896q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5T1376 1664H416q-119 0-203.5-84.5T128 1376V416q0-119 84.5-203.5T416 128h960q119 0 203.5 84.5T1664 416z\"/></svg>
";
        
        $__internal_dc6ca391c9a14ab7087f9d6f11053dd8b17b4b4862477f3cb0e4a432aeaf308c->leave($__internal_dc6ca391c9a14ab7087f9d6f11053dd8b17b4b4862477f3cb0e4a432aeaf308c_prof);

        
        $__internal_83ca84e23e4041893a9969901b516df6c42598d7e03a1bc780addbc613c1be6c->leave($__internal_83ca84e23e4041893a9969901b516df6c42598d7e03a1bc780addbc613c1be6c_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/icon-minus-square.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960V832q0-26-19-45t-45-19H448q-26 0-45 19t-19 45v128q0 26 19 45t45 19h896q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5T1376 1664H416q-119 0-203.5-84.5T128 1376V416q0-119 84.5-203.5T416 128h960q119 0 203.5 84.5T1664 416z\"/></svg>
", "@Twig/images/icon-minus-square.svg", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/twig-bundle/Resources/views/images/icon-minus-square.svg");
    }
}
