<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_9d4a788f989092a4a266edb2b54614bae0e105e958396dd447847b7364e9c77b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0ceef6b827243dc78b94bc46d09675aae63d75077f55e98285d9f0b1a2d8c07d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0ceef6b827243dc78b94bc46d09675aae63d75077f55e98285d9f0b1a2d8c07d->enter($__internal_0ceef6b827243dc78b94bc46d09675aae63d75077f55e98285d9f0b1a2d8c07d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        $__internal_4d195314148d72689a24b0ac9bddeea44ea8a2162ad51086b4a93fc063400e8e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4d195314148d72689a24b0ac9bddeea44ea8a2162ad51086b4a93fc063400e8e->enter($__internal_4d195314148d72689a24b0ac9bddeea44ea8a2162ad51086b4a93fc063400e8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes'); ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form); ?>
        </td>
    </tr>
    <?php endif; ?>
    <?php echo \$view['form']->block(\$form, 'form_rows'); ?>
    <?php echo \$view['form']->rest(\$form); ?>
</table>
";
        
        $__internal_0ceef6b827243dc78b94bc46d09675aae63d75077f55e98285d9f0b1a2d8c07d->leave($__internal_0ceef6b827243dc78b94bc46d09675aae63d75077f55e98285d9f0b1a2d8c07d_prof);

        
        $__internal_4d195314148d72689a24b0ac9bddeea44ea8a2162ad51086b4a93fc063400e8e->leave($__internal_4d195314148d72689a24b0ac9bddeea44ea8a2162ad51086b4a93fc063400e8e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes'); ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form); ?>
        </td>
    </tr>
    <?php endif; ?>
    <?php echo \$view['form']->block(\$form, 'form_rows'); ?>
    <?php echo \$view['form']->rest(\$form); ?>
</table>
", "@Framework/FormTable/form_widget_compound.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/FormTable/form_widget_compound.html.php");
    }
}
