<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_df16860bdab32b5a09881f5219d166b5c3040e0ab66d2328151c238c9bb372fd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_40a13eff6973ec352940bf04aec48b971959b1cd5a74a7cbf6600d3e8f84b1ed = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_40a13eff6973ec352940bf04aec48b971959b1cd5a74a7cbf6600d3e8f84b1ed->enter($__internal_40a13eff6973ec352940bf04aec48b971959b1cd5a74a7cbf6600d3e8f84b1ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        $__internal_b778a4c651615dbb3832d404c35dbf3c5849634357902a5ce6c4a5dace39abd6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b778a4c651615dbb3832d404c35dbf3c5849634357902a5ce6c4a5dace39abd6->enter($__internal_b778a4c651615dbb3832d404c35dbf3c5849634357902a5ce6c4a5dace39abd6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_40a13eff6973ec352940bf04aec48b971959b1cd5a74a7cbf6600d3e8f84b1ed->leave($__internal_40a13eff6973ec352940bf04aec48b971959b1cd5a74a7cbf6600d3e8f84b1ed_prof);

        
        $__internal_b778a4c651615dbb3832d404c35dbf3c5849634357902a5ce6c4a5dace39abd6->leave($__internal_b778a4c651615dbb3832d404c35dbf3c5849634357902a5ce6c4a5dace39abd6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/button_row.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/button_row.html.php");
    }
}
