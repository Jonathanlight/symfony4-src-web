<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_18dc87228c95db2d51b0781663a80205736059d621140ef074aa9303ecc76657 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f00af3242b653e3cc57a592788d77365a958c56ccbcb1148250d986395f291e6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f00af3242b653e3cc57a592788d77365a958c56ccbcb1148250d986395f291e6->enter($__internal_f00af3242b653e3cc57a592788d77365a958c56ccbcb1148250d986395f291e6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        $__internal_57cfe96255fc59e9d585275da658d7c7fb388116eccb848ca7701b148339c074 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_57cfe96255fc59e9d585275da658d7c7fb388116eccb848ca7701b148339c074->enter($__internal_57cfe96255fc59e9d585275da658d7c7fb388116eccb848ca7701b148339c074_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_f00af3242b653e3cc57a592788d77365a958c56ccbcb1148250d986395f291e6->leave($__internal_f00af3242b653e3cc57a592788d77365a958c56ccbcb1148250d986395f291e6_prof);

        
        $__internal_57cfe96255fc59e9d585275da658d7c7fb388116eccb848ca7701b148339c074->leave($__internal_57cfe96255fc59e9d585275da658d7c7fb388116eccb848ca7701b148339c074_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
", "@Framework/Form/reset_widget.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/reset_widget.html.php");
    }
}
