<?php

/* page/save.html.twig */
class __TwigTemplate_1d94ae76a9955838d23668bda6675922694721840825ab1dd107c505707fd5d1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "page/save.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b841f17ca9186ce21a7cfeeb27636f5dc5677a0016bb77735c943049369916ff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b841f17ca9186ce21a7cfeeb27636f5dc5677a0016bb77735c943049369916ff->enter($__internal_b841f17ca9186ce21a7cfeeb27636f5dc5677a0016bb77735c943049369916ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "page/save.html.twig"));

        $__internal_9b9cf7bdb536a078f3d1b39e405d51a6f1a9547f32404dccd8a7bcb6fab8c323 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9b9cf7bdb536a078f3d1b39e405d51a6f1a9547f32404dccd8a7bcb6fab8c323->enter($__internal_9b9cf7bdb536a078f3d1b39e405d51a6f1a9547f32404dccd8a7bcb6fab8c323_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "page/save.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b841f17ca9186ce21a7cfeeb27636f5dc5677a0016bb77735c943049369916ff->leave($__internal_b841f17ca9186ce21a7cfeeb27636f5dc5677a0016bb77735c943049369916ff_prof);

        
        $__internal_9b9cf7bdb536a078f3d1b39e405d51a6f1a9547f32404dccd8a7bcb6fab8c323->leave($__internal_9b9cf7bdb536a078f3d1b39e405d51a6f1a9547f32404dccd8a7bcb6fab8c323_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_3038c47b9dfc85765997c98e4fffb19ea65b3a47f411938a05c66cc71c3a6fe3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3038c47b9dfc85765997c98e4fffb19ea65b3a47f411938a05c66cc71c3a6fe3->enter($__internal_3038c47b9dfc85765997c98e4fffb19ea65b3a47f411938a05c66cc71c3a6fe3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_a62bbd1db074c0e8b4f8ab0641f20078deb8280433fc754f622713cb8af63a00 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a62bbd1db074c0e8b4f8ab0641f20078deb8280433fc754f622713cb8af63a00->enter($__internal_a62bbd1db074c0e8b4f8ab0641f20078deb8280433fc754f622713cb8af63a00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">

        <div class=\"starter-template\">
            <h1>Formulaire</h1>
        </div>

        <ul class=\"well\">
            ";
        // line 11
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 11, $this->getSourceContext()); })()), 'form_start');
        echo "
                ";
        // line 12
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 12, $this->getSourceContext()); })()), "name", array()), 'row');
        echo "
                ";
        // line 13
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 13, $this->getSourceContext()); })()), "price", array()), 'row');
        echo "
                ";
        // line 14
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 14, $this->getSourceContext()); })()), "description", array()), 'row');
        echo "
            ";
        // line 15
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 15, $this->getSourceContext()); })()), 'form_end');
        echo "
        </ul>

    </div><!-- /.container -->
";
        
        $__internal_a62bbd1db074c0e8b4f8ab0641f20078deb8280433fc754f622713cb8af63a00->leave($__internal_a62bbd1db074c0e8b4f8ab0641f20078deb8280433fc754f622713cb8af63a00_prof);

        
        $__internal_3038c47b9dfc85765997c98e4fffb19ea65b3a47f411938a05c66cc71c3a6fe3->leave($__internal_3038c47b9dfc85765997c98e4fffb19ea65b3a47f411938a05c66cc71c3a6fe3_prof);

    }

    public function getTemplateName()
    {
        return "page/save.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 15,  70 => 14,  66 => 13,  62 => 12,  58 => 11,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">

        <div class=\"starter-template\">
            <h1>Formulaire</h1>
        </div>

        <ul class=\"well\">
            {{ form_start(form) }}
                {{ form_row(form.name) }}
                {{ form_row(form.price) }}
                {{ form_row(form.description) }}
            {{ form_end(form) }}
        </ul>

    </div><!-- /.container -->
{% endblock %}", "page/save.html.twig", "/Users/admin/Desktop/Work/Jonathan/demo/src/Resources/views/page/save.html.twig");
    }
}
