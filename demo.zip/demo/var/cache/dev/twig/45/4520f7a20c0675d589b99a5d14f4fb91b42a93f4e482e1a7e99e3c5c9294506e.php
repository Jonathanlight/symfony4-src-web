<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_7a729312258fcd0b5b9a3c16d83b5f30bf8b5dd76ba81c31ce7223cc38333ad7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_90d20832ade660eabf161bddd3569f5fb899752a50596484232d67c541753666 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_90d20832ade660eabf161bddd3569f5fb899752a50596484232d67c541753666->enter($__internal_90d20832ade660eabf161bddd3569f5fb899752a50596484232d67c541753666_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        $__internal_6fc63439efd1d8928ad64d28f3c8d9659d8dc4f6bd1c07bac1d0fc23d93f0414 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6fc63439efd1d8928ad64d28f3c8d9659d8dc4f6bd1c07bac1d0fc23d93f0414->enter($__internal_6fc63439efd1d8928ad64d28f3c8d9659d8dc4f6bd1c07bac1d0fc23d93f0414_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_90d20832ade660eabf161bddd3569f5fb899752a50596484232d67c541753666->leave($__internal_90d20832ade660eabf161bddd3569f5fb899752a50596484232d67c541753666_prof);

        
        $__internal_6fc63439efd1d8928ad64d28f3c8d9659d8dc4f6bd1c07bac1d0fc23d93f0414->leave($__internal_6fc63439efd1d8928ad64d28f3c8d9659d8dc4f6bd1c07bac1d0fc23d93f0414_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
", "@Framework/Form/form_rest.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/form_rest.html.php");
    }
}
