<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_1af154762831ee4bd47c726b81fffca95b06d82ae81b175c76312b69c8cd0a21 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d8d8c1f79f50559c377cb62ef44150f528f91572d8d16e5ccf09f69c51aeb450 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d8d8c1f79f50559c377cb62ef44150f528f91572d8d16e5ccf09f69c51aeb450->enter($__internal_d8d8c1f79f50559c377cb62ef44150f528f91572d8d16e5ccf09f69c51aeb450_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_13845eeeaeabdecb6bf6cf01d5e91ac0344a9aba3b1dd68ed9e7224dfbf746ae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_13845eeeaeabdecb6bf6cf01d5e91ac0344a9aba3b1dd68ed9e7224dfbf746ae->enter($__internal_13845eeeaeabdecb6bf6cf01d5e91ac0344a9aba3b1dd68ed9e7224dfbf746ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d8d8c1f79f50559c377cb62ef44150f528f91572d8d16e5ccf09f69c51aeb450->leave($__internal_d8d8c1f79f50559c377cb62ef44150f528f91572d8d16e5ccf09f69c51aeb450_prof);

        
        $__internal_13845eeeaeabdecb6bf6cf01d5e91ac0344a9aba3b1dd68ed9e7224dfbf746ae->leave($__internal_13845eeeaeabdecb6bf6cf01d5e91ac0344a9aba3b1dd68ed9e7224dfbf746ae_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_f30be4bef82d467565b18de984474249f8108ef933e35bf0cd3294f0e9d15ec3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f30be4bef82d467565b18de984474249f8108ef933e35bf0cd3294f0e9d15ec3->enter($__internal_f30be4bef82d467565b18de984474249f8108ef933e35bf0cd3294f0e9d15ec3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_807078d490481bd58ffa4a588d53ed29f9baf7c5aba73698229c3bd50976f8dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_807078d490481bd58ffa4a588d53ed29f9baf7c5aba73698229c3bd50976f8dc->enter($__internal_807078d490481bd58ffa4a588d53ed29f9baf7c5aba73698229c3bd50976f8dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 4, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 6, $this->getSourceContext()); })()))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_807078d490481bd58ffa4a588d53ed29f9baf7c5aba73698229c3bd50976f8dc->leave($__internal_807078d490481bd58ffa4a588d53ed29f9baf7c5aba73698229c3bd50976f8dc_prof);

        
        $__internal_f30be4bef82d467565b18de984474249f8108ef933e35bf0cd3294f0e9d15ec3->leave($__internal_f30be4bef82d467565b18de984474249f8108ef933e35bf0cd3294f0e9d15ec3_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_56871c4ffbd7fe7dc5ed9159cdca251ac101f801178fa9177a8de1a0c0379be3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_56871c4ffbd7fe7dc5ed9159cdca251ac101f801178fa9177a8de1a0c0379be3->enter($__internal_56871c4ffbd7fe7dc5ed9159cdca251ac101f801178fa9177a8de1a0c0379be3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_54ace4e95355aeca7084b35111ecbfef9d5b4e8fe49fa2ae54a94295c9e9840b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_54ace4e95355aeca7084b35111ecbfef9d5b4e8fe49fa2ae54a94295c9e9840b->enter($__internal_54ace4e95355aeca7084b35111ecbfef9d5b4e8fe49fa2ae54a94295c9e9840b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo ((twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 13, $this->getSourceContext()); })()), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if (twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 16, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_54ace4e95355aeca7084b35111ecbfef9d5b4e8fe49fa2ae54a94295c9e9840b->leave($__internal_54ace4e95355aeca7084b35111ecbfef9d5b4e8fe49fa2ae54a94295c9e9840b_prof);

        
        $__internal_56871c4ffbd7fe7dc5ed9159cdca251ac101f801178fa9177a8de1a0c0379be3->leave($__internal_56871c4ffbd7fe7dc5ed9159cdca251ac101f801178fa9177a8de1a0c0379be3_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_e7ebe37ac116f44488976d927a13a3f26f2aff8d38c22a5f0a768889d3b120f0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e7ebe37ac116f44488976d927a13a3f26f2aff8d38c22a5f0a768889d3b120f0->enter($__internal_e7ebe37ac116f44488976d927a13a3f26f2aff8d38c22a5f0a768889d3b120f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_9f21df9c9b407e2492fd1248c898035e79eb59c6d621a0f270e59b30ffae37da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9f21df9c9b407e2492fd1248c898035e79eb59c6d621a0f270e59b30ffae37da->enter($__internal_9f21df9c9b407e2492fd1248c898035e79eb59c6d621a0f270e59b30ffae37da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["collector"]) || array_key_exists("collector", $context) ? $context["collector"] : (function () { throw new Twig_Error_Runtime('Variable "collector" does not exist.', 27, $this->getSourceContext()); })()), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new Twig_Error_Runtime('Variable "token" does not exist.', 33, $this->getSourceContext()); })()))));
            echo "
        </div>
    ";
        }
        
        $__internal_9f21df9c9b407e2492fd1248c898035e79eb59c6d621a0f270e59b30ffae37da->leave($__internal_9f21df9c9b407e2492fd1248c898035e79eb59c6d621a0f270e59b30ffae37da_prof);

        
        $__internal_e7ebe37ac116f44488976d927a13a3f26f2aff8d38c22a5f0a768889d3b120f0->leave($__internal_e7ebe37ac116f44488976d927a13a3f26f2aff8d38c22a5f0a768889d3b120f0_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/web-profiler-bundle/Resources/views/Collector/exception.html.twig");
    }
}
