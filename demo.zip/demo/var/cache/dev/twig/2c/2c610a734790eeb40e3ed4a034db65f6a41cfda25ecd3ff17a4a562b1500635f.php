<?php

/* @Framework/Form/widget_container_attributes.html.php */
class __TwigTemplate_218f0227e0f43165dfe90d3e6d47642905c27c9a7410019686475cbd062a3b6f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7731a08f74ba2bd65eb67850d29e01d8b51d86a871b0b402bbdbf5815bd91943 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7731a08f74ba2bd65eb67850d29e01d8b51d86a871b0b402bbdbf5815bd91943->enter($__internal_7731a08f74ba2bd65eb67850d29e01d8b51d86a871b0b402bbdbf5815bd91943_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        $__internal_d40f6c2e59e3704336be197f5354e3652e850a70cf6a2f533d98a0d6d5796f17 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d40f6c2e59e3704336be197f5354e3652e850a70cf6a2f533d98a0d6d5796f17->enter($__internal_d40f6c2e59e3704336be197f5354e3652e850a70cf6a2f533d98a0d6d5796f17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_container_attributes.html.php"));

        // line 1
        echo "<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_7731a08f74ba2bd65eb67850d29e01d8b51d86a871b0b402bbdbf5815bd91943->leave($__internal_7731a08f74ba2bd65eb67850d29e01d8b51d86a871b0b402bbdbf5815bd91943_prof);

        
        $__internal_d40f6c2e59e3704336be197f5354e3652e850a70cf6a2f533d98a0d6d5796f17->leave($__internal_d40f6c2e59e3704336be197f5354e3652e850a70cf6a2f533d98a0d6d5796f17_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!empty(\$id)): ?>id=\"<?php echo \$view->escape(\$id) ?>\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_container_attributes.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/widget_container_attributes.html.php");
    }
}
