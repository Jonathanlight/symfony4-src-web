<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_b62929048bcfe3b9be2421ebcd42a31652e1527b6a01b847706cdb0668ca0828 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7d662e9ff9df51ab3d3c0d37589e22b893523207d383784b4b19be7718b57d59 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7d662e9ff9df51ab3d3c0d37589e22b893523207d383784b4b19be7718b57d59->enter($__internal_7d662e9ff9df51ab3d3c0d37589e22b893523207d383784b4b19be7718b57d59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        $__internal_15705b4fca067ab4b8995c5fc9611e93a4f70ccbe3d56041aa5be252d99fae8e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_15705b4fca067ab4b8995c5fc9611e93a4f70ccbe3d56041aa5be252d99fae8e->enter($__internal_15705b4fca067ab4b8995c5fc9611e93a4f70ccbe3d56041aa5be252d99fae8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_7d662e9ff9df51ab3d3c0d37589e22b893523207d383784b4b19be7718b57d59->leave($__internal_7d662e9ff9df51ab3d3c0d37589e22b893523207d383784b4b19be7718b57d59_prof);

        
        $__internal_15705b4fca067ab4b8995c5fc9611e93a4f70ccbe3d56041aa5be252d99fae8e->leave($__internal_15705b4fca067ab4b8995c5fc9611e93a4f70ccbe3d56041aa5be252d99fae8e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
", "@Framework/Form/collection_widget.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/collection_widget.html.php");
    }
}
