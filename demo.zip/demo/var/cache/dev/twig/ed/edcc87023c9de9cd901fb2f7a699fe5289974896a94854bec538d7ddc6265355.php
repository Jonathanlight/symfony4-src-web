<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_e2ee3d3cf5d46e87619069f3e7fcc732ffed741789c094284600c327b0f5b444 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f589147ad24b7906e7e43b1874503afd02d25d1e0f0943bf73069d8764abec5c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f589147ad24b7906e7e43b1874503afd02d25d1e0f0943bf73069d8764abec5c->enter($__internal_f589147ad24b7906e7e43b1874503afd02d25d1e0f0943bf73069d8764abec5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        $__internal_18c3143a5add7099c1b3dede9d2d29a6aff899d8b8ec5abc775313fa7b149805 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_18c3143a5add7099c1b3dede9d2d29a6aff899d8b8ec5abc775313fa7b149805->enter($__internal_18c3143a5add7099c1b3dede9d2d29a6aff899d8b8ec5abc775313fa7b149805_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_f589147ad24b7906e7e43b1874503afd02d25d1e0f0943bf73069d8764abec5c->leave($__internal_f589147ad24b7906e7e43b1874503afd02d25d1e0f0943bf73069d8764abec5c_prof);

        
        $__internal_18c3143a5add7099c1b3dede9d2d29a6aff899d8b8ec5abc775313fa7b149805->leave($__internal_18c3143a5add7099c1b3dede9d2d29a6aff899d8b8ec5abc775313fa7b149805_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/choice_options.html.php");
    }
}
