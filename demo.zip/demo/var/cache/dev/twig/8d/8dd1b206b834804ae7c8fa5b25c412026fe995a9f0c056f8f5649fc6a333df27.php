<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_a54a52cfc59192d21ba9877a95bf5d0ea434fd9bc6d3bd2bf0f5f925e120974a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_115c15f379b21b62821b9fd437e4c706ca5b29ddcacc874e75f0428032318b46 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_115c15f379b21b62821b9fd437e4c706ca5b29ddcacc874e75f0428032318b46->enter($__internal_115c15f379b21b62821b9fd437e4c706ca5b29ddcacc874e75f0428032318b46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        $__internal_92308563ec1a816816b3c07874f924d12390ee7c0ef7371c4e2dab397377e459 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_92308563ec1a816816b3c07874f924d12390ee7c0ef7371c4e2dab397377e459->enter($__internal_92308563ec1a816816b3c07874f924d12390ee7c0ef7371c4e2dab397377e459_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_115c15f379b21b62821b9fd437e4c706ca5b29ddcacc874e75f0428032318b46->leave($__internal_115c15f379b21b62821b9fd437e4c706ca5b29ddcacc874e75f0428032318b46_prof);

        
        $__internal_92308563ec1a816816b3c07874f924d12390ee7c0ef7371c4e2dab397377e459->leave($__internal_92308563ec1a816816b3c07874f924d12390ee7c0ef7371c4e2dab397377e459_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_35378fdb2c62282e66cb7356741aa7c7b1c9778d3ea62d19025a1449c25abb4a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_35378fdb2c62282e66cb7356741aa7c7b1c9778d3ea62d19025a1449c25abb4a->enter($__internal_35378fdb2c62282e66cb7356741aa7c7b1c9778d3ea62d19025a1449c25abb4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_39b01e4913ba05e6170a3d7c25d0edc929de8c2a83c98056e155b437b80f95a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_39b01e4913ba05e6170a3d7c25d0edc929de8c2a83c98056e155b437b80f95a2->enter($__internal_39b01e4913ba05e6170a3d7c25d0edc929de8c2a83c98056e155b437b80f95a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_39b01e4913ba05e6170a3d7c25d0edc929de8c2a83c98056e155b437b80f95a2->leave($__internal_39b01e4913ba05e6170a3d7c25d0edc929de8c2a83c98056e155b437b80f95a2_prof);

        
        $__internal_35378fdb2c62282e66cb7356741aa7c7b1c9778d3ea62d19025a1449c25abb4a->leave($__internal_35378fdb2c62282e66cb7356741aa7c7b1c9778d3ea62d19025a1449c25abb4a_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/web-profiler-bundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
