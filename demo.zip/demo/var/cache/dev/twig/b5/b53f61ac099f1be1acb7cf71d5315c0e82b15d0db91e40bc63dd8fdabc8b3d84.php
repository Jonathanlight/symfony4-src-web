<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_a138d40d353f1ccfa466943b8805ac10313ae85297091d365579d57a2fc58aba extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_996be000c33af5cdd33c859404df1718c9ed50d2add57f622c65f92600d1d554 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_996be000c33af5cdd33c859404df1718c9ed50d2add57f622c65f92600d1d554->enter($__internal_996be000c33af5cdd33c859404df1718c9ed50d2add57f622c65f92600d1d554_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        $__internal_3e220a9c5830e0c843cbafe64dc98f940bfbdd549b05c04b4c4e56c978de79df = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3e220a9c5830e0c843cbafe64dc98f940bfbdd549b05c04b4c4e56c978de79df->enter($__internal_3e220a9c5830e0c843cbafe64dc98f940bfbdd549b05c04b4c4e56c978de79df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_996be000c33af5cdd33c859404df1718c9ed50d2add57f622c65f92600d1d554->leave($__internal_996be000c33af5cdd33c859404df1718c9ed50d2add57f622c65f92600d1d554_prof);

        
        $__internal_3e220a9c5830e0c843cbafe64dc98f940bfbdd549b05c04b4c4e56c978de79df->leave($__internal_3e220a9c5830e0c843cbafe64dc98f940bfbdd549b05c04b4c4e56c978de79df_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
", "@Framework/Form/form_widget_simple.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/form_widget_simple.html.php");
    }
}
