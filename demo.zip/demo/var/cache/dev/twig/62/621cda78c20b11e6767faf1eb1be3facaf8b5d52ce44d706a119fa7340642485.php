<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_749beac652d167a42eef4753fd55e7f685a8db843c96b6bb021d648d82d3e82b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_db8edb626eade48278abb3922055305c18c293e8db66b9e87b9d1159f4f110da = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_db8edb626eade48278abb3922055305c18c293e8db66b9e87b9d1159f4f110da->enter($__internal_db8edb626eade48278abb3922055305c18c293e8db66b9e87b9d1159f4f110da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        $__internal_d57541cf259e9f99347e46ea4f317dd0ae8cf8ab43862760c526f31f1f0e5cb0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d57541cf259e9f99347e46ea4f317dd0ae8cf8ab43862760c526f31f1f0e5cb0->enter($__internal_d57541cf259e9f99347e46ea4f317dd0ae8cf8ab43862760c526f31f1f0e5cb0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_db8edb626eade48278abb3922055305c18c293e8db66b9e87b9d1159f4f110da->leave($__internal_db8edb626eade48278abb3922055305c18c293e8db66b9e87b9d1159f4f110da_prof);

        
        $__internal_d57541cf259e9f99347e46ea4f317dd0ae8cf8ab43862760c526f31f1f0e5cb0->leave($__internal_d57541cf259e9f99347e46ea4f317dd0ae8cf8ab43862760c526f31f1f0e5cb0_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.rdf.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/twig-bundle/Resources/views/Exception/error.rdf.twig");
    }
}
