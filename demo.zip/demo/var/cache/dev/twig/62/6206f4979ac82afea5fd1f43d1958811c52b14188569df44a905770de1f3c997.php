<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_edcf4f4c2a81999a011c7c2591ef60d0cfa3d5644362dba15e53e7da3114404b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d53fe723f75a56c35bd6dac72079e47bd19b2b7528cf71570f6e1bc12ed58ea0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d53fe723f75a56c35bd6dac72079e47bd19b2b7528cf71570f6e1bc12ed58ea0->enter($__internal_d53fe723f75a56c35bd6dac72079e47bd19b2b7528cf71570f6e1bc12ed58ea0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        $__internal_84b7fd40278afe60e8eaa66b270cd6b0caf40d3c9c79cfcffef0fb59f1c0e00c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_84b7fd40278afe60e8eaa66b270cd6b0caf40d3c9c79cfcffef0fb59f1c0e00c->enter($__internal_84b7fd40278afe60e8eaa66b270cd6b0caf40d3c9c79cfcffef0fb59f1c0e00c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_d53fe723f75a56c35bd6dac72079e47bd19b2b7528cf71570f6e1bc12ed58ea0->leave($__internal_d53fe723f75a56c35bd6dac72079e47bd19b2b7528cf71570f6e1bc12ed58ea0_prof);

        
        $__internal_84b7fd40278afe60e8eaa66b270cd6b0caf40d3c9c79cfcffef0fb59f1c0e00c->leave($__internal_84b7fd40278afe60e8eaa66b270cd6b0caf40d3c9c79cfcffef0fb59f1c0e00c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
", "@Framework/Form/container_attributes.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/container_attributes.html.php");
    }
}
