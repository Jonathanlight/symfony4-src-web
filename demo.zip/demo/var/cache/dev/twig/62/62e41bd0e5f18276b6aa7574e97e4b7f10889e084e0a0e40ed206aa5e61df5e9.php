<?php

/* @Framework/Form/button_widget.html.php */
class __TwigTemplate_ec616e2db50fe6faf180bd13095cc90d1f2250ae26bfdac54996183ca076cf47 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c89801e9e3d8fc90ef5dda33adcc55f398672decc50fa8dfe7555d1e5050672a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c89801e9e3d8fc90ef5dda33adcc55f398672decc50fa8dfe7555d1e5050672a->enter($__internal_c89801e9e3d8fc90ef5dda33adcc55f398672decc50fa8dfe7555d1e5050672a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        $__internal_af1e6d7b0bc71d99001d1d1256ef087a3e8dab47877723fd947ed5da3fc73cd9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_af1e6d7b0bc71d99001d1d1256ef087a3e8dab47877723fd947ed5da3fc73cd9->enter($__internal_af1e6d7b0bc71d99001d1d1256ef087a3e8dab47877723fd947ed5da3fc73cd9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        // line 1
        echo "<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
";
        
        $__internal_c89801e9e3d8fc90ef5dda33adcc55f398672decc50fa8dfe7555d1e5050672a->leave($__internal_c89801e9e3d8fc90ef5dda33adcc55f398672decc50fa8dfe7555d1e5050672a_prof);

        
        $__internal_af1e6d7b0bc71d99001d1d1256ef087a3e8dab47877723fd947ed5da3fc73cd9->leave($__internal_af1e6d7b0bc71d99001d1d1256ef087a3e8dab47877723fd947ed5da3fc73cd9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
", "@Framework/Form/button_widget.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/button_widget.html.php");
    }
}
