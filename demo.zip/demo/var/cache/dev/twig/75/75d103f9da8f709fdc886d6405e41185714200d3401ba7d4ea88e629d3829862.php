<?php

/* @Framework/Form/form_start.html.php */
class __TwigTemplate_85ee04d45c2bcd85eedbfb653f9405db8677ab1ba730cba9bc863951b7bf55c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_69b14ef0493e98a14989375ba7b60edddd3e5c6d12672680f6efffaa33e2099a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_69b14ef0493e98a14989375ba7b60edddd3e5c6d12672680f6efffaa33e2099a->enter($__internal_69b14ef0493e98a14989375ba7b60edddd3e5c6d12672680f6efffaa33e2099a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_start.html.php"));

        $__internal_63ae798cac8c254a4d0b95779c09d5bcc00a2b33dc1ded07b6abe6b060a9a849 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63ae798cac8c254a4d0b95779c09d5bcc00a2b33dc1ded07b6abe6b060a9a849->enter($__internal_63ae798cac8c254a4d0b95779c09d5bcc00a2b33dc1ded07b6abe6b060a9a849_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_start.html.php"));

        // line 1
        echo "<?php \$method = strtoupper(\$method) ?>
<?php \$form_method = \$method === 'GET' || \$method === 'POST' ? \$method : 'POST' ?>
<form name=\"<?php echo \$name ?>\" method=\"<?php echo strtolower(\$form_method) ?>\"<?php if (\$action !== ''): ?> action=\"<?php echo \$action ?>\"<?php endif ?><?php foreach (\$attr as \$k => \$v) { printf(' %s=\"%s\"', \$view->escape(\$k), \$view->escape(\$v)); } ?><?php if (\$multipart): ?> enctype=\"multipart/form-data\"<?php endif ?>>
<?php if (\$form_method !== \$method): ?>
    <input type=\"hidden\" name=\"_method\" value=\"<?php echo \$method ?>\" />
<?php endif ?>
";
        
        $__internal_69b14ef0493e98a14989375ba7b60edddd3e5c6d12672680f6efffaa33e2099a->leave($__internal_69b14ef0493e98a14989375ba7b60edddd3e5c6d12672680f6efffaa33e2099a_prof);

        
        $__internal_63ae798cac8c254a4d0b95779c09d5bcc00a2b33dc1ded07b6abe6b060a9a849->leave($__internal_63ae798cac8c254a4d0b95779c09d5bcc00a2b33dc1ded07b6abe6b060a9a849_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_start.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php \$method = strtoupper(\$method) ?>
<?php \$form_method = \$method === 'GET' || \$method === 'POST' ? \$method : 'POST' ?>
<form name=\"<?php echo \$name ?>\" method=\"<?php echo strtolower(\$form_method) ?>\"<?php if (\$action !== ''): ?> action=\"<?php echo \$action ?>\"<?php endif ?><?php foreach (\$attr as \$k => \$v) { printf(' %s=\"%s\"', \$view->escape(\$k), \$view->escape(\$v)); } ?><?php if (\$multipart): ?> enctype=\"multipart/form-data\"<?php endif ?>>
<?php if (\$form_method !== \$method): ?>
    <input type=\"hidden\" name=\"_method\" value=\"<?php echo \$method ?>\" />
<?php endif ?>
", "@Framework/Form/form_start.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/form_start.html.php");
    }
}
