<?php

/* @Twig/Exception/exception.css.twig */
class __TwigTemplate_9eff9d6b69622fda25fdb562e5759dcb08344f5db04a6995d1af21e53772a43f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ff364245d162772c82cdcba5c6f1814bf9c5dbb63f3a6f4574b69c2db381e511 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ff364245d162772c82cdcba5c6f1814bf9c5dbb63f3a6f4574b69c2db381e511->enter($__internal_ff364245d162772c82cdcba5c6f1814bf9c5dbb63f3a6f4574b69c2db381e511_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        $__internal_87c1c2a3e08e71e809fe77d62ae544f68ba3c3dc130ef05b902394430201f5c7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_87c1c2a3e08e71e809fe77d62ae544f68ba3c3dc130ef05b902394430201f5c7->enter($__internal_87c1c2a3e08e71e809fe77d62ae544f68ba3c3dc130ef05b902394430201f5c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 2, $this->getSourceContext()); })())));
        echo "
*/
";
        
        $__internal_ff364245d162772c82cdcba5c6f1814bf9c5dbb63f3a6f4574b69c2db381e511->leave($__internal_ff364245d162772c82cdcba5c6f1814bf9c5dbb63f3a6f4574b69c2db381e511_prof);

        
        $__internal_87c1c2a3e08e71e809fe77d62ae544f68ba3c3dc130ef05b902394430201f5c7->leave($__internal_87c1c2a3e08e71e809fe77d62ae544f68ba3c3dc130ef05b902394430201f5c7_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "@Twig/Exception/exception.css.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/twig-bundle/Resources/views/Exception/exception.css.twig");
    }
}
