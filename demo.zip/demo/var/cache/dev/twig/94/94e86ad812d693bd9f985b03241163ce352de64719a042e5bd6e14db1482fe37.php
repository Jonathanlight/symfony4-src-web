<?php

/* @Twig/Exception/traces.xml.twig */
class __TwigTemplate_159a5d07a1c10272b9536930c1fc56328a1d456977f74b7c596137fb39277732 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bfe050444a38cfa5e9bd4ca1edb7d71da3a7eff1be00461e10c5ebb7c16dff59 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bfe050444a38cfa5e9bd4ca1edb7d71da3a7eff1be00461e10c5ebb7c16dff59->enter($__internal_bfe050444a38cfa5e9bd4ca1edb7d71da3a7eff1be00461e10c5ebb7c16dff59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/traces.xml.twig"));

        $__internal_c3f9019f67639f5a38c392c2a01b8f4b882b9d7525cbe360828e8182b3082acf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c3f9019f67639f5a38c392c2a01b8f4b882b9d7525cbe360828e8182b3082acf->enter($__internal_c3f9019f67639f5a38c392c2a01b8f4b882b9d7525cbe360828e8182b3082acf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/traces.xml.twig"));

        // line 1
        echo "        <traces>
";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 2, $this->getSourceContext()); })()), "trace", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["trace"]) {
            // line 3
            echo "            <trace>
";
            // line 4
            echo twig_include($this->env, $context, "@Twig/Exception/trace.txt.twig", array("trace" => $context["trace"]), false);
            echo "

            </trace>
";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['trace'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 8
        echo "        </traces>
";
        
        $__internal_bfe050444a38cfa5e9bd4ca1edb7d71da3a7eff1be00461e10c5ebb7c16dff59->leave($__internal_bfe050444a38cfa5e9bd4ca1edb7d71da3a7eff1be00461e10c5ebb7c16dff59_prof);

        
        $__internal_c3f9019f67639f5a38c392c2a01b8f4b882b9d7525cbe360828e8182b3082acf->leave($__internal_c3f9019f67639f5a38c392c2a01b8f4b882b9d7525cbe360828e8182b3082acf_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/traces.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  45 => 8,  35 => 4,  32 => 3,  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("        <traces>
{% for trace in exception.trace %}
            <trace>
{{ include('@Twig/Exception/trace.txt.twig', { trace: trace }, with_context = false) }}

            </trace>
{% endfor %}
        </traces>
", "@Twig/Exception/traces.xml.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/twig-bundle/Resources/views/Exception/traces.xml.twig");
    }
}
