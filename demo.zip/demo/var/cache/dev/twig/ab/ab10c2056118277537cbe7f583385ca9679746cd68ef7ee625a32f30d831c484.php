<?php

/* @Framework/Form/button_attributes.html.php */
class __TwigTemplate_a064029a0682db78a34326d74b26009d246bcac9c2194cf25a75b369e73a3818 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e7b8ed936a820b35864594cdb2d32d4cc67746d2fd98752327044647d91abc2c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e7b8ed936a820b35864594cdb2d32d4cc67746d2fd98752327044647d91abc2c->enter($__internal_e7b8ed936a820b35864594cdb2d32d4cc67746d2fd98752327044647d91abc2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_attributes.html.php"));

        $__internal_b18819ff9df45b2ed9a7221bebaa0474f6204c08acedbb4e063d2bcf888e881d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b18819ff9df45b2ed9a7221bebaa0474f6204c08acedbb4e063d2bcf888e881d->enter($__internal_b18819ff9df45b2ed9a7221bebaa0474f6204c08acedbb4e063d2bcf888e881d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_attributes.html.php"));

        // line 1
        echo "id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_e7b8ed936a820b35864594cdb2d32d4cc67746d2fd98752327044647d91abc2c->leave($__internal_e7b8ed936a820b35864594cdb2d32d4cc67746d2fd98752327044647d91abc2c_prof);

        
        $__internal_b18819ff9df45b2ed9a7221bebaa0474f6204c08acedbb4e063d2bcf888e881d->leave($__internal_b18819ff9df45b2ed9a7221bebaa0474f6204c08acedbb4e063d2bcf888e881d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/button_attributes.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/button_attributes.html.php");
    }
}
