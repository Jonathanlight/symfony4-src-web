<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_63ffb8fb9a5a10efb5fe34f385f451a48528d7d317b7e3c338176a279f5104f9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_49b291ef51b30519b4d6ecfcbc7b6350a76ca0d58c29a564914851fdc45a1ebe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_49b291ef51b30519b4d6ecfcbc7b6350a76ca0d58c29a564914851fdc45a1ebe->enter($__internal_49b291ef51b30519b4d6ecfcbc7b6350a76ca0d58c29a564914851fdc45a1ebe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        $__internal_22a0cb4cb5a9dd0ed1357de500834bf49d8790759a9ff346ac9e589c33bf12ae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_22a0cb4cb5a9dd0ed1357de500834bf49d8790759a9ff346ac9e589c33bf12ae->enter($__internal_22a0cb4cb5a9dd0ed1357de500834bf49d8790759a9ff346ac9e589c33bf12ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/error.xml.twig");
        echo "
";
        
        $__internal_49b291ef51b30519b4d6ecfcbc7b6350a76ca0d58c29a564914851fdc45a1ebe->leave($__internal_49b291ef51b30519b4d6ecfcbc7b6350a76ca0d58c29a564914851fdc45a1ebe_prof);

        
        $__internal_22a0cb4cb5a9dd0ed1357de500834bf49d8790759a9ff346ac9e589c33bf12ae->leave($__internal_22a0cb4cb5a9dd0ed1357de500834bf49d8790759a9ff346ac9e589c33bf12ae_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/error.xml.twig') }}
", "@Twig/Exception/error.atom.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/twig-bundle/Resources/views/Exception/error.atom.twig");
    }
}
