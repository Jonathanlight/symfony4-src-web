<?php

/* page/edit.html.twig */
class __TwigTemplate_1be98e60841fd0f80c363ded2451692af1d69e573930527ae71ffe5a8da2d566 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "page/edit.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3edc7bae43d9986b859eac36fbd8928ca1c31ecc348e9bcdeae0145ba5a0b9c0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3edc7bae43d9986b859eac36fbd8928ca1c31ecc348e9bcdeae0145ba5a0b9c0->enter($__internal_3edc7bae43d9986b859eac36fbd8928ca1c31ecc348e9bcdeae0145ba5a0b9c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "page/edit.html.twig"));

        $__internal_bb7018e85c13a4a3f8d0ad7183bad1d7ffd936f6ff5f188e1ad7ca633e1915a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bb7018e85c13a4a3f8d0ad7183bad1d7ffd936f6ff5f188e1ad7ca633e1915a2->enter($__internal_bb7018e85c13a4a3f8d0ad7183bad1d7ffd936f6ff5f188e1ad7ca633e1915a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "page/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3edc7bae43d9986b859eac36fbd8928ca1c31ecc348e9bcdeae0145ba5a0b9c0->leave($__internal_3edc7bae43d9986b859eac36fbd8928ca1c31ecc348e9bcdeae0145ba5a0b9c0_prof);

        
        $__internal_bb7018e85c13a4a3f8d0ad7183bad1d7ffd936f6ff5f188e1ad7ca633e1915a2->leave($__internal_bb7018e85c13a4a3f8d0ad7183bad1d7ffd936f6ff5f188e1ad7ca633e1915a2_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_eb3e9a55ac8595b7be9d69485c59191c3ae6425ab402b53f96cfc6fce4cfc944 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eb3e9a55ac8595b7be9d69485c59191c3ae6425ab402b53f96cfc6fce4cfc944->enter($__internal_eb3e9a55ac8595b7be9d69485c59191c3ae6425ab402b53f96cfc6fce4cfc944_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_b18c9c17bb1d17339cad80bdd81aaf9a9e1a4ba78227bb184c3d7d371a4b1dd8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b18c9c17bb1d17339cad80bdd81aaf9a9e1a4ba78227bb184c3d7d371a4b1dd8->enter($__internal_b18c9c17bb1d17339cad80bdd81aaf9a9e1a4ba78227bb184c3d7d371a4b1dd8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"container\">
        <div class=\"starter-template\">
            <h1>Formulaire</h1>
        </div>
        <ul class=\"well\">
            ";
        // line 9
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 9, $this->getSourceContext()); })()), 'form_start', array("attr" => array("class" => "form-horizontal")));
        echo "
            ";
        // line 10
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 10, $this->getSourceContext()); })()), "name", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "Name product")));
        echo "
            ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 11, $this->getSourceContext()); })()), "price", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "Price product")));
        echo "
            ";
        // line 12
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 12, $this->getSourceContext()); })()), "description", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "Description product")));
        echo "
            ";
        // line 13
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 13, $this->getSourceContext()); })()), "save", array()), 'row', array("attr" => array("class" => "btn btn-success")));
        echo "
            ";
        // line 14
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 14, $this->getSourceContext()); })()), 'form_end');
        echo "
        </ul>
    </div>
";
        
        $__internal_b18c9c17bb1d17339cad80bdd81aaf9a9e1a4ba78227bb184c3d7d371a4b1dd8->leave($__internal_b18c9c17bb1d17339cad80bdd81aaf9a9e1a4ba78227bb184c3d7d371a4b1dd8_prof);

        
        $__internal_eb3e9a55ac8595b7be9d69485c59191c3ae6425ab402b53f96cfc6fce4cfc944->leave($__internal_eb3e9a55ac8595b7be9d69485c59191c3ae6425ab402b53f96cfc6fce4cfc944_prof);

    }

    public function getTemplateName()
    {
        return "page/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 14,  72 => 13,  68 => 12,  64 => 11,  60 => 10,  56 => 9,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    <div class=\"container\">
        <div class=\"starter-template\">
            <h1>Formulaire</h1>
        </div>
        <ul class=\"well\">
            {{ form_start(form, {'attr': {'class': 'form-horizontal'}}) }}
            {{ form_row(form.name, {'attr': {'class': 'form-control', 'placeholder':'Name product'}}) }}
            {{ form_row(form.price, {'attr': {'class': 'form-control', 'placeholder':'Price product'}}) }}
            {{ form_row(form.description, {'attr': {'class': 'form-control', 'placeholder':'Description product'}}) }}
            {{ form_row(form.save, {'attr': {'class': 'btn btn-success'}}) }}
            {{ form_end(form) }}
        </ul>
    </div>
{% endblock %}", "page/edit.html.twig", "/Users/admin/Desktop/Work/Jonathan/demo/src/Resources/views/page/edit.html.twig");
    }
}
