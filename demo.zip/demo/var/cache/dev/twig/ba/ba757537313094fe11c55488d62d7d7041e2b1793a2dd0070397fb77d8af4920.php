<?php

/* base.html.twig */
class __TwigTemplate_601d878d60ac97cc38810ec27d40d6ddfd4aac9427c38fd65d3efc36405e8f84 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8bbed04649d1f516466fde935d3958cafbe127db7e0812ee9ae7815e1aa1c2b0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8bbed04649d1f516466fde935d3958cafbe127db7e0812ee9ae7815e1aa1c2b0->enter($__internal_8bbed04649d1f516466fde935d3958cafbe127db7e0812ee9ae7815e1aa1c2b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_2e4af933bffbd1d9dfa5495c74d1ff6f951b0eabca72c5211994a7be01b09f3a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e4af933bffbd1d9dfa5495c74d1ff6f951b0eabca72c5211994a7be01b09f3a->enter($__internal_2e4af933bffbd1d9dfa5495c74d1ff6f951b0eabca72c5211994a7be01b09f3a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"https://v4-alpha.getbootstrap.com/favicon.ico\">

    <title>";
        // line 12
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 13
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 14
        echo "
    <!-- Bootstrap core CSS -->
    <link href=\"https://getbootstrap.com/docs/3.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href=\"https://getbootstrap.com/docs/3.3/assets/css/ie10-viewport-bug-workaround.css\" rel=\"stylesheet\">

    <!-- Custom styles for this template -->
    <link href=\"https://getbootstrap.com/docs/3.3/examples/starter-template/starter-template.css\" rel=\"stylesheet\">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
    <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
    <![endif]-->
</head>

<body>

<nav class=\"navbar navbar-inverse navbar-fixed-top\">
    <div class=\"container\">
        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"";
        // line 42
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">SF4</a>
        </div>
        <div id=\"navbar\" class=\"collapse navbar-collapse\">
            <ul class=\"nav navbar-nav\">
                <li class=\"active\"><a href=\"";
        // line 46
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">Home</a></li>
                <li><a href=\"";
        // line 47
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("save");
        echo "\">Save</a></li>
            </ul>
        </div><!--/.nav-collapse -->
    </div>
</nav>

";
        // line 53
        $this->displayBlock('body', $context, $blocks);
        // line 56
        $this->displayBlock('javascripts', $context, $blocks);
        // line 57
        echo "<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\"></script>
<script>window.jQuery || document.write('<script src=\"../../assets/js/vendor/jquery.min.js\"><\\/script>')</script>
<script src=\"https://getbootstrap.com/docs/3.3/dist/js/bootstrap.min.js\"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src=\"../../assets/js/ie10-viewport-bug-workaround.js\"></script>
</body>
</html>
";
        
        $__internal_8bbed04649d1f516466fde935d3958cafbe127db7e0812ee9ae7815e1aa1c2b0->leave($__internal_8bbed04649d1f516466fde935d3958cafbe127db7e0812ee9ae7815e1aa1c2b0_prof);

        
        $__internal_2e4af933bffbd1d9dfa5495c74d1ff6f951b0eabca72c5211994a7be01b09f3a->leave($__internal_2e4af933bffbd1d9dfa5495c74d1ff6f951b0eabca72c5211994a7be01b09f3a_prof);

    }

    // line 12
    public function block_title($context, array $blocks = array())
    {
        $__internal_b3da36e9267893651dd71ee2e13a1228f3c50723cf6bbf495a0349e57ab7a581 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b3da36e9267893651dd71ee2e13a1228f3c50723cf6bbf495a0349e57ab7a581->enter($__internal_b3da36e9267893651dd71ee2e13a1228f3c50723cf6bbf495a0349e57ab7a581_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_84d6c61f4e41c7d94b14bde147e23b4cfa27b3ebeaa2fb80ce818ae6f81cbdab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_84d6c61f4e41c7d94b14bde147e23b4cfa27b3ebeaa2fb80ce818ae6f81cbdab->enter($__internal_84d6c61f4e41c7d94b14bde147e23b4cfa27b3ebeaa2fb80ce818ae6f81cbdab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_84d6c61f4e41c7d94b14bde147e23b4cfa27b3ebeaa2fb80ce818ae6f81cbdab->leave($__internal_84d6c61f4e41c7d94b14bde147e23b4cfa27b3ebeaa2fb80ce818ae6f81cbdab_prof);

        
        $__internal_b3da36e9267893651dd71ee2e13a1228f3c50723cf6bbf495a0349e57ab7a581->leave($__internal_b3da36e9267893651dd71ee2e13a1228f3c50723cf6bbf495a0349e57ab7a581_prof);

    }

    // line 13
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_9ae2cbd0761a601e92989f2e4b337214e5e960e3be1d7e4152715e642c415d5b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9ae2cbd0761a601e92989f2e4b337214e5e960e3be1d7e4152715e642c415d5b->enter($__internal_9ae2cbd0761a601e92989f2e4b337214e5e960e3be1d7e4152715e642c415d5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_b2ee8ee5ecc36d917410f22abc4450ca4451d3dfd222edb424df6ba26dd6ba06 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b2ee8ee5ecc36d917410f22abc4450ca4451d3dfd222edb424df6ba26dd6ba06->enter($__internal_b2ee8ee5ecc36d917410f22abc4450ca4451d3dfd222edb424df6ba26dd6ba06_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_b2ee8ee5ecc36d917410f22abc4450ca4451d3dfd222edb424df6ba26dd6ba06->leave($__internal_b2ee8ee5ecc36d917410f22abc4450ca4451d3dfd222edb424df6ba26dd6ba06_prof);

        
        $__internal_9ae2cbd0761a601e92989f2e4b337214e5e960e3be1d7e4152715e642c415d5b->leave($__internal_9ae2cbd0761a601e92989f2e4b337214e5e960e3be1d7e4152715e642c415d5b_prof);

    }

    // line 53
    public function block_body($context, array $blocks = array())
    {
        $__internal_4059d7694f25063b58bab7ef903b391b3148339eb52164dd0204ee56c0c20c89 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4059d7694f25063b58bab7ef903b391b3148339eb52164dd0204ee56c0c20c89->enter($__internal_4059d7694f25063b58bab7ef903b391b3148339eb52164dd0204ee56c0c20c89_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_05401aa8d019ebe60bba4d6d93618681624e5ef36a1439d41f449ed3f03332de = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_05401aa8d019ebe60bba4d6d93618681624e5ef36a1439d41f449ed3f03332de->enter($__internal_05401aa8d019ebe60bba4d6d93618681624e5ef36a1439d41f449ed3f03332de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 54
        echo "    <hr>
";
        
        $__internal_05401aa8d019ebe60bba4d6d93618681624e5ef36a1439d41f449ed3f03332de->leave($__internal_05401aa8d019ebe60bba4d6d93618681624e5ef36a1439d41f449ed3f03332de_prof);

        
        $__internal_4059d7694f25063b58bab7ef903b391b3148339eb52164dd0204ee56c0c20c89->leave($__internal_4059d7694f25063b58bab7ef903b391b3148339eb52164dd0204ee56c0c20c89_prof);

    }

    // line 56
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_788850c54606838e5f5afd19e338915c5d1abab989abd8c7863919772f874f24 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_788850c54606838e5f5afd19e338915c5d1abab989abd8c7863919772f874f24->enter($__internal_788850c54606838e5f5afd19e338915c5d1abab989abd8c7863919772f874f24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_934a7c04a206b71808fe32810b2fbeefb67d9e0ab6052d8bda7e3f854ff56716 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_934a7c04a206b71808fe32810b2fbeefb67d9e0ab6052d8bda7e3f854ff56716->enter($__internal_934a7c04a206b71808fe32810b2fbeefb67d9e0ab6052d8bda7e3f854ff56716_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_934a7c04a206b71808fe32810b2fbeefb67d9e0ab6052d8bda7e3f854ff56716->leave($__internal_934a7c04a206b71808fe32810b2fbeefb67d9e0ab6052d8bda7e3f854ff56716_prof);

        
        $__internal_788850c54606838e5f5afd19e338915c5d1abab989abd8c7863919772f874f24->leave($__internal_788850c54606838e5f5afd19e338915c5d1abab989abd8c7863919772f874f24_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  177 => 56,  166 => 54,  157 => 53,  140 => 13,  122 => 12,  102 => 57,  100 => 56,  98 => 53,  89 => 47,  85 => 46,  78 => 42,  48 => 14,  46 => 13,  42 => 12,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"https://v4-alpha.getbootstrap.com/favicon.ico\">

    <title>{% block title %}Welcome!{% endblock %}</title>
    {% block stylesheets %}{% endblock %}

    <!-- Bootstrap core CSS -->
    <link href=\"https://getbootstrap.com/docs/3.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href=\"https://getbootstrap.com/docs/3.3/assets/css/ie10-viewport-bug-workaround.css\" rel=\"stylesheet\">

    <!-- Custom styles for this template -->
    <link href=\"https://getbootstrap.com/docs/3.3/examples/starter-template/starter-template.css\" rel=\"stylesheet\">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
    <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
    <![endif]-->
</head>

<body>

<nav class=\"navbar navbar-inverse navbar-fixed-top\">
    <div class=\"container\">
        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"{{ path('homepage') }}\">SF4</a>
        </div>
        <div id=\"navbar\" class=\"collapse navbar-collapse\">
            <ul class=\"nav navbar-nav\">
                <li class=\"active\"><a href=\"{{ path('homepage') }}\">Home</a></li>
                <li><a href=\"{{ path('save') }}\">Save</a></li>
            </ul>
        </div><!--/.nav-collapse -->
    </div>
</nav>

{% block body %}
    <hr>
{% endblock %}
{% block javascripts %}{% endblock %}
<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\"></script>
<script>window.jQuery || document.write('<script src=\"../../assets/js/vendor/jquery.min.js\"><\\/script>')</script>
<script src=\"https://getbootstrap.com/docs/3.3/dist/js/bootstrap.min.js\"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src=\"../../assets/js/ie10-viewport-bug-workaround.js\"></script>
</body>
</html>
", "base.html.twig", "/Users/admin/Desktop/Work/Jonathan/demo/templates/base.html.twig");
    }
}
