<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_f76151d0fc7fc494fb6ea42435daf5eb6c4bf30b7be372f799919e7ae5e8bbdd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5a8dcddee1a234fd78cabd4334401eaf46bfa9dc25d5a887f6bc405cc0e4e221 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5a8dcddee1a234fd78cabd4334401eaf46bfa9dc25d5a887f6bc405cc0e4e221->enter($__internal_5a8dcddee1a234fd78cabd4334401eaf46bfa9dc25d5a887f6bc405cc0e4e221_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        $__internal_261c7c9206d9ae386fc4da200be76a6a72093273e1a87d13cc038be9909db990 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_261c7c9206d9ae386fc4da200be76a6a72093273e1a87d13cc038be9909db990->enter($__internal_261c7c9206d9ae386fc4da200be76a6a72093273e1a87d13cc038be9909db990_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_5a8dcddee1a234fd78cabd4334401eaf46bfa9dc25d5a887f6bc405cc0e4e221->leave($__internal_5a8dcddee1a234fd78cabd4334401eaf46bfa9dc25d5a887f6bc405cc0e4e221_prof);

        
        $__internal_261c7c9206d9ae386fc4da200be76a6a72093273e1a87d13cc038be9909db990->leave($__internal_261c7c9206d9ae386fc4da200be76a6a72093273e1a87d13cc038be9909db990_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
", "@Framework/Form/form_widget_compound.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/form_widget_compound.html.php");
    }
}
