<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_c978b96f8ec481a81d47bb637053225a4b89ea81589fece3c16f4d607c20f2c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_609403618a018b29f024f7cccd39f89f9c8e875052341402ad68cb923e90a48c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_609403618a018b29f024f7cccd39f89f9c8e875052341402ad68cb923e90a48c->enter($__internal_609403618a018b29f024f7cccd39f89f9c8e875052341402ad68cb923e90a48c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_d712398f000d20364917947a54873bfbcf44f8bcc6788bfee5539db82cdc3db2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d712398f000d20364917947a54873bfbcf44f8bcc6788bfee5539db82cdc3db2->enter($__internal_d712398f000d20364917947a54873bfbcf44f8bcc6788bfee5539db82cdc3db2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_609403618a018b29f024f7cccd39f89f9c8e875052341402ad68cb923e90a48c->leave($__internal_609403618a018b29f024f7cccd39f89f9c8e875052341402ad68cb923e90a48c_prof);

        
        $__internal_d712398f000d20364917947a54873bfbcf44f8bcc6788bfee5539db82cdc3db2->leave($__internal_d712398f000d20364917947a54873bfbcf44f8bcc6788bfee5539db82cdc3db2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/textarea_widget.html.php");
    }
}
