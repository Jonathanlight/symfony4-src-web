<?php

/* @WebProfiler/Profiler/open.html.twig */
class __TwigTemplate_9fcdfcfe8ed501883dd2d1388f71a6629ea9f074a5896c42d0e36f13e8509192 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "@WebProfiler/Profiler/open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3d917beb0a18bbe6386ff0621bf9c6157a2bb82c8bb22b5699ecc6b8054f5788 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3d917beb0a18bbe6386ff0621bf9c6157a2bb82c8bb22b5699ecc6b8054f5788->enter($__internal_3d917beb0a18bbe6386ff0621bf9c6157a2bb82c8bb22b5699ecc6b8054f5788_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $__internal_3caf7432fd8f97a76edef989746b021f14f8070c0a058ae6d839eed7bdffc8e9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3caf7432fd8f97a76edef989746b021f14f8070c0a058ae6d839eed7bdffc8e9->enter($__internal_3caf7432fd8f97a76edef989746b021f14f8070c0a058ae6d839eed7bdffc8e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3d917beb0a18bbe6386ff0621bf9c6157a2bb82c8bb22b5699ecc6b8054f5788->leave($__internal_3d917beb0a18bbe6386ff0621bf9c6157a2bb82c8bb22b5699ecc6b8054f5788_prof);

        
        $__internal_3caf7432fd8f97a76edef989746b021f14f8070c0a058ae6d839eed7bdffc8e9->leave($__internal_3caf7432fd8f97a76edef989746b021f14f8070c0a058ae6d839eed7bdffc8e9_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_a8b359623b79766d84ef5235f727d5b82806e8233454a72bad554c8230c921fe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a8b359623b79766d84ef5235f727d5b82806e8233454a72bad554c8230c921fe->enter($__internal_a8b359623b79766d84ef5235f727d5b82806e8233454a72bad554c8230c921fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_284fa2d2b528ef7756856fe31a7e286495a6ed6762a7294a190b478c285165fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_284fa2d2b528ef7756856fe31a7e286495a6ed6762a7294a190b478c285165fe->enter($__internal_284fa2d2b528ef7756856fe31a7e286495a6ed6762a7294a190b478c285165fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_284fa2d2b528ef7756856fe31a7e286495a6ed6762a7294a190b478c285165fe->leave($__internal_284fa2d2b528ef7756856fe31a7e286495a6ed6762a7294a190b478c285165fe_prof);

        
        $__internal_a8b359623b79766d84ef5235f727d5b82806e8233454a72bad554c8230c921fe->leave($__internal_a8b359623b79766d84ef5235f727d5b82806e8233454a72bad554c8230c921fe_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_65342043d22b57239ef984f2c1af6ea045564fbbc9ec378b3072cb40157268d7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_65342043d22b57239ef984f2c1af6ea045564fbbc9ec378b3072cb40157268d7->enter($__internal_65342043d22b57239ef984f2c1af6ea045564fbbc9ec378b3072cb40157268d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_fbe84a75c840f567941aa7b904189f68745bca6a938dc15c909273fd8017fd77 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fbe84a75c840f567941aa7b904189f68745bca6a938dc15c909273fd8017fd77->enter($__internal_fbe84a75c840f567941aa7b904189f68745bca6a938dc15c909273fd8017fd77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["file"]) || array_key_exists("file", $context) ? $context["file"] : (function () { throw new Twig_Error_Runtime('Variable "file" does not exist.', 11, $this->getSourceContext()); })()), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, (isset($context["line"]) || array_key_exists("line", $context) ? $context["line"] : (function () { throw new Twig_Error_Runtime('Variable "line" does not exist.', 11, $this->getSourceContext()); })()), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt((isset($context["filename"]) || array_key_exists("filename", $context) ? $context["filename"] : (function () { throw new Twig_Error_Runtime('Variable "filename" does not exist.', 15, $this->getSourceContext()); })()), (isset($context["line"]) || array_key_exists("line", $context) ? $context["line"] : (function () { throw new Twig_Error_Runtime('Variable "line" does not exist.', 15, $this->getSourceContext()); })()),  -1);
        echo "
</div>
";
        
        $__internal_fbe84a75c840f567941aa7b904189f68745bca6a938dc15c909273fd8017fd77->leave($__internal_fbe84a75c840f567941aa7b904189f68745bca6a938dc15c909273fd8017fd77_prof);

        
        $__internal_65342043d22b57239ef984f2c1af6ea045564fbbc9ec378b3072cb40157268d7->leave($__internal_65342043d22b57239ef984f2c1af6ea045564fbbc9ec378b3072cb40157268d7_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "@WebProfiler/Profiler/open.html.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/web-profiler-bundle/Resources/views/Profiler/open.html.twig");
    }
}
