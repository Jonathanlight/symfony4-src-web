<?php

/* @Twig/Exception/error.js.twig */
class __TwigTemplate_69f00af42941921f3e0297f7f6b83f2e63af0cdd2bed88709b2b92a163332f8e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0c86968f433c7040d4ee758b05327a2d06f90f1ed4219bae24147c0b0de51417 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0c86968f433c7040d4ee758b05327a2d06f90f1ed4219bae24147c0b0de51417->enter($__internal_0c86968f433c7040d4ee758b05327a2d06f90f1ed4219bae24147c0b0de51417_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        $__internal_81fea6d571fa294fbd94aae58cc78a5213c314b54019f213d60d24f52ffee36e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_81fea6d571fa294fbd94aae58cc78a5213c314b54019f213d60d24f52ffee36e->enter($__internal_81fea6d571fa294fbd94aae58cc78a5213c314b54019f213d60d24f52ffee36e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 2, $this->getSourceContext()); })()), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 2, $this->getSourceContext()); })()), "js", null, true);
        echo "

*/
";
        
        $__internal_0c86968f433c7040d4ee758b05327a2d06f90f1ed4219bae24147c0b0de51417->leave($__internal_0c86968f433c7040d4ee758b05327a2d06f90f1ed4219bae24147c0b0de51417_prof);

        
        $__internal_81fea6d571fa294fbd94aae58cc78a5213c314b54019f213d60d24f52ffee36e->leave($__internal_81fea6d571fa294fbd94aae58cc78a5213c314b54019f213d60d24f52ffee36e_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "@Twig/Exception/error.js.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/twig-bundle/Resources/views/Exception/error.js.twig");
    }
}
