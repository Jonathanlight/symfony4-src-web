<?php

/* base.html.twig */
class __TwigTemplate_d725284c39a66870e1a2039161012602874dbab8bbfa53374b1aa87634ceba5c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c95adc3232843c08b9034c8dec8102eb5ec65926d6161cc8714971513bfd34b7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c95adc3232843c08b9034c8dec8102eb5ec65926d6161cc8714971513bfd34b7->enter($__internal_c95adc3232843c08b9034c8dec8102eb5ec65926d6161cc8714971513bfd34b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_64869df9b6fa388bdc4442d3e5c5755a542a884e3a9e18226ae95745e1ab6f14 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_64869df9b6fa388bdc4442d3e5c5755a542a884e3a9e18226ae95745e1ab6f14->enter($__internal_64869df9b6fa388bdc4442d3e5c5755a542a884e3a9e18226ae95745e1ab6f14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"https://v4-alpha.getbootstrap.com/favicon.ico\">

    <title>";
        // line 12
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 13
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 14
        echo "
    <!-- Bootstrap core CSS -->
    <link href=\"https://getbootstrap.com/docs/3.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href=\"https://getbootstrap.com/docs/3.3/assets/css/ie10-viewport-bug-workaround.css\" rel=\"stylesheet\">

    <!-- Custom styles for this template -->
    <link href=\"https://getbootstrap.com/docs/3.3/examples/starter-template/starter-template.css\" rel=\"stylesheet\">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
    <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
    <![endif]-->
</head>

<body>

<nav class=\"navbar navbar-inverse navbar-fixed-top\">
    <div class=\"container\">
        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"";
        // line 42
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">SF4</a>
        </div>
        <div id=\"navbar\" class=\"collapse navbar-collapse\">
            <ul class=\"nav navbar-nav\">
                <li class=\"active\"><a href=\"";
        // line 46
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">Home</a></li>
                <li class=\"active\"><a href=\"";
        // line 47
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("other");
        echo "\">Documentation</a></li>
            </ul>
        </div><!--/.nav-collapse -->
    </div>
</nav>

";
        // line 53
        $this->displayBlock('body', $context, $blocks);
        // line 56
        $this->displayBlock('javascripts', $context, $blocks);
        // line 57
        echo "<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\"></script>
<script>window.jQuery || document.write('<script src=\"../../assets/js/vendor/jquery.min.js\"><\\/script>')</script>
<script src=\"https://getbootstrap.com/docs/3.3/dist/js/bootstrap.min.js\"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src=\"../../assets/js/ie10-viewport-bug-workaround.js\"></script>
</body>
</html>
";
        
        $__internal_c95adc3232843c08b9034c8dec8102eb5ec65926d6161cc8714971513bfd34b7->leave($__internal_c95adc3232843c08b9034c8dec8102eb5ec65926d6161cc8714971513bfd34b7_prof);

        
        $__internal_64869df9b6fa388bdc4442d3e5c5755a542a884e3a9e18226ae95745e1ab6f14->leave($__internal_64869df9b6fa388bdc4442d3e5c5755a542a884e3a9e18226ae95745e1ab6f14_prof);

    }

    // line 12
    public function block_title($context, array $blocks = array())
    {
        $__internal_22a36238f1838a29a10124872d78fa9570eb174ef233092153ca5d4553f7ac61 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_22a36238f1838a29a10124872d78fa9570eb174ef233092153ca5d4553f7ac61->enter($__internal_22a36238f1838a29a10124872d78fa9570eb174ef233092153ca5d4553f7ac61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_ca08bbb12a65920cafd7a649ec26c9c06647b716be28aa2bd5432f8ac545c0f6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca08bbb12a65920cafd7a649ec26c9c06647b716be28aa2bd5432f8ac545c0f6->enter($__internal_ca08bbb12a65920cafd7a649ec26c9c06647b716be28aa2bd5432f8ac545c0f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_ca08bbb12a65920cafd7a649ec26c9c06647b716be28aa2bd5432f8ac545c0f6->leave($__internal_ca08bbb12a65920cafd7a649ec26c9c06647b716be28aa2bd5432f8ac545c0f6_prof);

        
        $__internal_22a36238f1838a29a10124872d78fa9570eb174ef233092153ca5d4553f7ac61->leave($__internal_22a36238f1838a29a10124872d78fa9570eb174ef233092153ca5d4553f7ac61_prof);

    }

    // line 13
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_f5bd5f6a5d54ed989fcdcb3fdadec8130094597468d886857704da2c0cf8bf6b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f5bd5f6a5d54ed989fcdcb3fdadec8130094597468d886857704da2c0cf8bf6b->enter($__internal_f5bd5f6a5d54ed989fcdcb3fdadec8130094597468d886857704da2c0cf8bf6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_8b9f0ca90ca8a578723fb39904d8e2c5477c605d2b9644f279d8a025e299c090 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8b9f0ca90ca8a578723fb39904d8e2c5477c605d2b9644f279d8a025e299c090->enter($__internal_8b9f0ca90ca8a578723fb39904d8e2c5477c605d2b9644f279d8a025e299c090_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_8b9f0ca90ca8a578723fb39904d8e2c5477c605d2b9644f279d8a025e299c090->leave($__internal_8b9f0ca90ca8a578723fb39904d8e2c5477c605d2b9644f279d8a025e299c090_prof);

        
        $__internal_f5bd5f6a5d54ed989fcdcb3fdadec8130094597468d886857704da2c0cf8bf6b->leave($__internal_f5bd5f6a5d54ed989fcdcb3fdadec8130094597468d886857704da2c0cf8bf6b_prof);

    }

    // line 53
    public function block_body($context, array $blocks = array())
    {
        $__internal_4fa0f89632974b2582f6e7c0263c7ab6f9fc396127a79b1900ae1670b635ad98 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4fa0f89632974b2582f6e7c0263c7ab6f9fc396127a79b1900ae1670b635ad98->enter($__internal_4fa0f89632974b2582f6e7c0263c7ab6f9fc396127a79b1900ae1670b635ad98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_8bd3cfb30eba180b10b4a3d5ba480f669af5876fb152198129ff78ae0c72a6dd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8bd3cfb30eba180b10b4a3d5ba480f669af5876fb152198129ff78ae0c72a6dd->enter($__internal_8bd3cfb30eba180b10b4a3d5ba480f669af5876fb152198129ff78ae0c72a6dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 54
        echo "    <hr>
";
        
        $__internal_8bd3cfb30eba180b10b4a3d5ba480f669af5876fb152198129ff78ae0c72a6dd->leave($__internal_8bd3cfb30eba180b10b4a3d5ba480f669af5876fb152198129ff78ae0c72a6dd_prof);

        
        $__internal_4fa0f89632974b2582f6e7c0263c7ab6f9fc396127a79b1900ae1670b635ad98->leave($__internal_4fa0f89632974b2582f6e7c0263c7ab6f9fc396127a79b1900ae1670b635ad98_prof);

    }

    // line 56
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_a0dd9d127264af8f1a6d4be85ff11597010d862586977519ec43d5e8946a37a0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a0dd9d127264af8f1a6d4be85ff11597010d862586977519ec43d5e8946a37a0->enter($__internal_a0dd9d127264af8f1a6d4be85ff11597010d862586977519ec43d5e8946a37a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_db8ccd052053050e400d955040f79842d3495863a5c914c01869b35c5ef68d43 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_db8ccd052053050e400d955040f79842d3495863a5c914c01869b35c5ef68d43->enter($__internal_db8ccd052053050e400d955040f79842d3495863a5c914c01869b35c5ef68d43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_db8ccd052053050e400d955040f79842d3495863a5c914c01869b35c5ef68d43->leave($__internal_db8ccd052053050e400d955040f79842d3495863a5c914c01869b35c5ef68d43_prof);

        
        $__internal_a0dd9d127264af8f1a6d4be85ff11597010d862586977519ec43d5e8946a37a0->leave($__internal_a0dd9d127264af8f1a6d4be85ff11597010d862586977519ec43d5e8946a37a0_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  177 => 56,  166 => 54,  157 => 53,  140 => 13,  122 => 12,  102 => 57,  100 => 56,  98 => 53,  89 => 47,  85 => 46,  78 => 42,  48 => 14,  46 => 13,  42 => 12,  29 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"utf-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"https://v4-alpha.getbootstrap.com/favicon.ico\">

    <title>{% block title %}Welcome!{% endblock %}</title>
    {% block stylesheets %}{% endblock %}

    <!-- Bootstrap core CSS -->
    <link href=\"https://getbootstrap.com/docs/3.3/dist/css/bootstrap.min.css\" rel=\"stylesheet\">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href=\"https://getbootstrap.com/docs/3.3/assets/css/ie10-viewport-bug-workaround.css\" rel=\"stylesheet\">

    <!-- Custom styles for this template -->
    <link href=\"https://getbootstrap.com/docs/3.3/examples/starter-template/starter-template.css\" rel=\"stylesheet\">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src=\"https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js\"></script>
    <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
    <![endif]-->
</head>

<body>

<nav class=\"navbar navbar-inverse navbar-fixed-top\">
    <div class=\"container\">
        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand\" href=\"{{ path('homepage') }}\">SF4</a>
        </div>
        <div id=\"navbar\" class=\"collapse navbar-collapse\">
            <ul class=\"nav navbar-nav\">
                <li class=\"active\"><a href=\"{{ path('homepage') }}\">Home</a></li>
                <li class=\"active\"><a href=\"{{ path('other') }}\">Documentation</a></li>
            </ul>
        </div><!--/.nav-collapse -->
    </div>
</nav>

{% block body %}
    <hr>
{% endblock %}
{% block javascripts %}{% endblock %}
<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\"></script>
<script>window.jQuery || document.write('<script src=\"../../assets/js/vendor/jquery.min.js\"><\\/script>')</script>
<script src=\"https://getbootstrap.com/docs/3.3/dist/js/bootstrap.min.js\"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src=\"../../assets/js/ie10-viewport-bug-workaround.js\"></script>
</body>
</html>
", "base.html.twig", "/Users/admin/Desktop/Work/Jonathan/demo/templates/base.html.twig");
    }
}
