<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_bf28957c5a2611cebe130a8c10093bb03c3ccc975e1e25dd2053440ed1401dc5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_68523bbab95ebe0ea1991eaa6ec0b742cf1203df16956aadbad34a0ef730c641 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_68523bbab95ebe0ea1991eaa6ec0b742cf1203df16956aadbad34a0ef730c641->enter($__internal_68523bbab95ebe0ea1991eaa6ec0b742cf1203df16956aadbad34a0ef730c641_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        $__internal_c9fe7fe3cc32dac0e3483aa40b97079f469bb867dfb1b9307e331714dc1c94c9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c9fe7fe3cc32dac0e3483aa40b97079f469bb867dfb1b9307e331714dc1c94c9->enter($__internal_c9fe7fe3cc32dac0e3483aa40b97079f469bb867dfb1b9307e331714dc1c94c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php foreach (\$attr as \$k => \$v): ?>
<?php if ('placeholder' === \$k || 'title' === \$k): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$v, array(), \$translation_domain) : \$v)) ?>
<?php elseif (true === \$v): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (false !== \$v): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
";
        
        $__internal_68523bbab95ebe0ea1991eaa6ec0b742cf1203df16956aadbad34a0ef730c641->leave($__internal_68523bbab95ebe0ea1991eaa6ec0b742cf1203df16956aadbad34a0ef730c641_prof);

        
        $__internal_c9fe7fe3cc32dac0e3483aa40b97079f469bb867dfb1b9307e331714dc1c94c9->leave($__internal_c9fe7fe3cc32dac0e3483aa40b97079f469bb867dfb1b9307e331714dc1c94c9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$attr as \$k => \$v): ?>
<?php if ('placeholder' === \$k || 'title' === \$k): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$v, array(), \$translation_domain) : \$v)) ?>
<?php elseif (true === \$v): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (false !== \$v): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
", "@Framework/Form/attributes.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/attributes.html.php");
    }
}
