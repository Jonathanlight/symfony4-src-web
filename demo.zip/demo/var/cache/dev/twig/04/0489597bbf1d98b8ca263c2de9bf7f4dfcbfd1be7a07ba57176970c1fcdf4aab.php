<?php

/* @Framework/Form/money_widget.html.php */
class __TwigTemplate_251511b25644b4f2e9edf26ddd7719bc204ad68324e610fe0736ecc5e0d3768e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4eef622c1b169fe732a0f89bbb2a50ab29b4f966164a9c4dc327572cc63938a5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4eef622c1b169fe732a0f89bbb2a50ab29b4f966164a9c4dc327572cc63938a5->enter($__internal_4eef622c1b169fe732a0f89bbb2a50ab29b4f966164a9c4dc327572cc63938a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        $__internal_f6fb6c611a3f61f5ae222ab243be2377d5ac8f37b2c3c57d90d4ce5415aa0499 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f6fb6c611a3f61f5ae222ab243be2377d5ac8f37b2c3c57d90d4ce5415aa0499->enter($__internal_f6fb6c611a3f61f5ae222ab243be2377d5ac8f37b2c3c57d90d4ce5415aa0499_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        // line 1
        echo "<?php echo str_replace('";
        echo twig_escape_filter($this->env, (isset($context["widget"]) || array_key_exists("widget", $context) ? $context["widget"] : (function () { throw new Twig_Error_Runtime('Variable "widget" does not exist.', 1, $this->getSourceContext()); })()), "html", null, true);
        echo "', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
";
        
        $__internal_4eef622c1b169fe732a0f89bbb2a50ab29b4f966164a9c4dc327572cc63938a5->leave($__internal_4eef622c1b169fe732a0f89bbb2a50ab29b4f966164a9c4dc327572cc63938a5_prof);

        
        $__internal_f6fb6c611a3f61f5ae222ab243be2377d5ac8f37b2c3c57d90d4ce5415aa0499->leave($__internal_f6fb6c611a3f61f5ae222ab243be2377d5ac8f37b2c3c57d90d4ce5415aa0499_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/money_widget.html.php";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo str_replace('{{ widget }}', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
", "@Framework/Form/money_widget.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/money_widget.html.php");
    }
}
