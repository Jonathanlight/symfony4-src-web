<?php

/* @Framework/Form/widget_attributes.html.php */
class __TwigTemplate_fb123e0be029c6486c44deccecca32deb7677125318c587a4d6792c48aae2517 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7d925595f3f90b29e9bd3d502de2a50b8a53e72d3d8996ee7c9af765997fd8f7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7d925595f3f90b29e9bd3d502de2a50b8a53e72d3d8996ee7c9af765997fd8f7->enter($__internal_7d925595f3f90b29e9bd3d502de2a50b8a53e72d3d8996ee7c9af765997fd8f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_attributes.html.php"));

        $__internal_48e2e05d665a0dfae3e065d75175b74a89b0a73f92b17d63fd35740b17812308 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_48e2e05d665a0dfae3e065d75175b74a89b0a73f92b17d63fd35740b17812308->enter($__internal_48e2e05d665a0dfae3e065d75175b74a89b0a73f92b17d63fd35740b17812308_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/widget_attributes.html.php"));

        // line 1
        echo "id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php if (\$required): ?> required=\"required\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
";
        
        $__internal_7d925595f3f90b29e9bd3d502de2a50b8a53e72d3d8996ee7c9af765997fd8f7->leave($__internal_7d925595f3f90b29e9bd3d502de2a50b8a53e72d3d8996ee7c9af765997fd8f7_prof);

        
        $__internal_48e2e05d665a0dfae3e065d75175b74a89b0a73f92b17d63fd35740b17812308->leave($__internal_48e2e05d665a0dfae3e065d75175b74a89b0a73f92b17d63fd35740b17812308_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/widget_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("id=\"<?php echo \$view->escape(\$id) ?>\" name=\"<?php echo \$view->escape(\$full_name) ?>\"<?php if (\$disabled): ?> disabled=\"disabled\"<?php endif ?>
<?php if (\$required): ?> required=\"required\"<?php endif ?>
<?php echo \$attr ? ' '.\$view['form']->block(\$form, 'attributes') : '' ?>
", "@Framework/Form/widget_attributes.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/widget_attributes.html.php");
    }
}
