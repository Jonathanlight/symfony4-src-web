<?php

/* @Twig/images/icon-plus-square.svg */
class __TwigTemplate_3ef36f8830cc00d3b1267ea3df282c2249792f384927abc43a8d37ab6b9a4102 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_199a53df90567d686b15590429f09680a845b612224a103ca3b946d174a56d9d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_199a53df90567d686b15590429f09680a845b612224a103ca3b946d174a56d9d->enter($__internal_199a53df90567d686b15590429f09680a845b612224a103ca3b946d174a56d9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-plus-square.svg"));

        $__internal_389e4bc3edb0d696affbd1486a010a1e6196a49601788f5ba97b9ebe8533a97b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_389e4bc3edb0d696affbd1486a010a1e6196a49601788f5ba97b9ebe8533a97b->enter($__internal_389e4bc3edb0d696affbd1486a010a1e6196a49601788f5ba97b9ebe8533a97b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-plus-square.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960v-128q0-26-19-45t-45-19h-320v-320q0-26-19-45t-45-19h-128q-26 0-45 19t-19 45v320h-320q-26 0-45 19t-19 45v128q0 26 19 45t45 19h320v320q0 26 19 45t45 19h128q26 0 45-19t19-45v-320h320q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5t-203.5 84.5h-960q-119 0-203.5-84.5t-84.5-203.5v-960q0-119 84.5-203.5t203.5-84.5h960q119 0 203.5 84.5t84.5 203.5z\"/></svg>
";
        
        $__internal_199a53df90567d686b15590429f09680a845b612224a103ca3b946d174a56d9d->leave($__internal_199a53df90567d686b15590429f09680a845b612224a103ca3b946d174a56d9d_prof);

        
        $__internal_389e4bc3edb0d696affbd1486a010a1e6196a49601788f5ba97b9ebe8533a97b->leave($__internal_389e4bc3edb0d696affbd1486a010a1e6196a49601788f5ba97b9ebe8533a97b_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/icon-plus-square.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960v-128q0-26-19-45t-45-19h-320v-320q0-26-19-45t-45-19h-128q-26 0-45 19t-19 45v320h-320q-26 0-45 19t-19 45v128q0 26 19 45t45 19h320v320q0 26 19 45t45 19h128q26 0 45-19t19-45v-320h320q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5t-203.5 84.5h-960q-119 0-203.5-84.5t-84.5-203.5v-960q0-119 84.5-203.5t203.5-84.5h960q119 0 203.5 84.5t84.5 203.5z\"/></svg>
", "@Twig/images/icon-plus-square.svg", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/twig-bundle/Resources/views/images/icon-plus-square.svg");
    }
}
