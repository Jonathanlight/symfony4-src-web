<?php

/* @Security/Collector/icon.svg */
class __TwigTemplate_32583143d733ba174dc86218ca69e52ef170e1af9233583fed454d7fcfb53440 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6b517d83fbd2e59cb19bbcf49f5df00564e002f0624f9b0888985a9de9c12506 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6b517d83fbd2e59cb19bbcf49f5df00564e002f0624f9b0888985a9de9c12506->enter($__internal_6b517d83fbd2e59cb19bbcf49f5df00564e002f0624f9b0888985a9de9c12506_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Security/Collector/icon.svg"));

        $__internal_5f8e4df3eb5fd51b077c2ed71ed33fe8bc18802d432d12f4c88119ffe2bca31d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5f8e4df3eb5fd51b077c2ed71ed33fe8bc18802d432d12f4c88119ffe2bca31d->enter($__internal_5f8e4df3eb5fd51b077c2ed71ed33fe8bc18802d432d12f4c88119ffe2bca31d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Security/Collector/icon.svg"));

        // line 1
        echo "<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
    <path fill=\"#AAAAAA\" d=\"M21,20.4V22H3v-1.6c0-3.7,2.4-6.9,5.8-8c-1.7-1.1-2.9-3-2.9-5.2c0-3.4,2.7-6.1,6.1-6.1s6.1,2.7,6.1,6.1c0,2.2-1.2,4.1-2.9,5.2C18.6,13.5,21,16.7,21,20.4z\"/>
</svg>
";
        
        $__internal_6b517d83fbd2e59cb19bbcf49f5df00564e002f0624f9b0888985a9de9c12506->leave($__internal_6b517d83fbd2e59cb19bbcf49f5df00564e002f0624f9b0888985a9de9c12506_prof);

        
        $__internal_5f8e4df3eb5fd51b077c2ed71ed33fe8bc18802d432d12f4c88119ffe2bca31d->leave($__internal_5f8e4df3eb5fd51b077c2ed71ed33fe8bc18802d432d12f4c88119ffe2bca31d_prof);

    }

    public function getTemplateName()
    {
        return "@Security/Collector/icon.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
    <path fill=\"#AAAAAA\" d=\"M21,20.4V22H3v-1.6c0-3.7,2.4-6.9,5.8-8c-1.7-1.1-2.9-3-2.9-5.2c0-3.4,2.7-6.1,6.1-6.1s6.1,2.7,6.1,6.1c0,2.2-1.2,4.1-2.9,5.2C18.6,13.5,21,16.7,21,20.4z\"/>
</svg>
", "@Security/Collector/icon.svg", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/security-bundle/Resources/views/Collector/icon.svg");
    }
}
