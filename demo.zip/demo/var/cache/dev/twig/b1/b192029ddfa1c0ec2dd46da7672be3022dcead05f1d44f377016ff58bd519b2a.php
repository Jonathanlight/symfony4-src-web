<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_fbe69b666174bf89f7871821cef35d2e71ccb3b928bdc2d59a06d477bed22470 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4976d1082dbc6c104942da505ae087d254b5e25a3b27f5478033d23588d84c0f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4976d1082dbc6c104942da505ae087d254b5e25a3b27f5478033d23588d84c0f->enter($__internal_4976d1082dbc6c104942da505ae087d254b5e25a3b27f5478033d23588d84c0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        $__internal_d2ec9ace1cea5d1bbb87ceaf8995a53c6bda6b53fb49097a894c1c9425f4328d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d2ec9ace1cea5d1bbb87ceaf8995a53c6bda6b53fb49097a894c1c9425f4328d->enter($__internal_d2ec9ace1cea5d1bbb87ceaf8995a53c6bda6b53fb49097a894c1c9425f4328d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_4976d1082dbc6c104942da505ae087d254b5e25a3b27f5478033d23588d84c0f->leave($__internal_4976d1082dbc6c104942da505ae087d254b5e25a3b27f5478033d23588d84c0f_prof);

        
        $__internal_d2ec9ace1cea5d1bbb87ceaf8995a53c6bda6b53fb49097a894c1c9425f4328d->leave($__internal_d2ec9ace1cea5d1bbb87ceaf8995a53c6bda6b53fb49097a894c1c9425f4328d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/radio_widget.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/radio_widget.html.php");
    }
}
