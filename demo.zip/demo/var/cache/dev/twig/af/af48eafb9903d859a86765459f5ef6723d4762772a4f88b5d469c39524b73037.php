<?php

/* @Twig/Exception/exception.js.twig */
class __TwigTemplate_94712d18bdee22c7b5c53aba9bf5929732096140995dc2fc101777e49e5603c2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b41e4ee0d50da6778ed2c2c868e9b263247207e4352a363ab8107adb3a389f97 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b41e4ee0d50da6778ed2c2c868e9b263247207e4352a363ab8107adb3a389f97->enter($__internal_b41e4ee0d50da6778ed2c2c868e9b263247207e4352a363ab8107adb3a389f97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        $__internal_b577eb718e1cff923bd34a24be1f0378313cffbadb94cbf3f4c286397b9a12a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b577eb718e1cff923bd34a24be1f0378313cffbadb94cbf3f4c286397b9a12a8->enter($__internal_b577eb718e1cff923bd34a24be1f0378313cffbadb94cbf3f4c286397b9a12a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_include($this->env, $context, "@Twig/Exception/exception.txt.twig", array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 2, $this->getSourceContext()); })())));
        echo "
*/
";
        
        $__internal_b41e4ee0d50da6778ed2c2c868e9b263247207e4352a363ab8107adb3a389f97->leave($__internal_b41e4ee0d50da6778ed2c2c868e9b263247207e4352a363ab8107adb3a389f97_prof);

        
        $__internal_b577eb718e1cff923bd34a24be1f0378313cffbadb94cbf3f4c286397b9a12a8->leave($__internal_b577eb718e1cff923bd34a24be1f0378313cffbadb94cbf3f4c286397b9a12a8_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ include('@Twig/Exception/exception.txt.twig', { exception: exception }) }}
*/
", "@Twig/Exception/exception.js.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/twig-bundle/Resources/views/Exception/exception.js.twig");
    }
}
