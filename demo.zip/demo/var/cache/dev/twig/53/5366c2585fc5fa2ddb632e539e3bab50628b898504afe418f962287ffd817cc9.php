<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_f4687907a8d5b3481dabcc4f4f12ad4a31ed75776b65a5ab2c90746215bf0900 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e92a7197f9c082bc8529cd6e77ed599e32cd623938169b974f964bcab7cd87c3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e92a7197f9c082bc8529cd6e77ed599e32cd623938169b974f964bcab7cd87c3->enter($__internal_e92a7197f9c082bc8529cd6e77ed599e32cd623938169b974f964bcab7cd87c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        $__internal_2000dc6e14a2db068bb0ccce6266cef27dd816020d0d17d4fa1885d1727ca159 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2000dc6e14a2db068bb0ccce6266cef27dd816020d0d17d4fa1885d1727ca159->enter($__internal_2000dc6e14a2db068bb0ccce6266cef27dd816020d0d17d4fa1885d1727ca159_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_e92a7197f9c082bc8529cd6e77ed599e32cd623938169b974f964bcab7cd87c3->leave($__internal_e92a7197f9c082bc8529cd6e77ed599e32cd623938169b974f964bcab7cd87c3_prof);

        
        $__internal_2000dc6e14a2db068bb0ccce6266cef27dd816020d0d17d4fa1885d1727ca159->leave($__internal_2000dc6e14a2db068bb0ccce6266cef27dd816020d0d17d4fa1885d1727ca159_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
", "@Framework/Form/form.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/form.html.php");
    }
}
