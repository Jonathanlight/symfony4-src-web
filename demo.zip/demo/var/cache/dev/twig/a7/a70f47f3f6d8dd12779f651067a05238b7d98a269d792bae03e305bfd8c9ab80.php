<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_efc28eb2ba8552a98afb4cfb454de89f05fe619a38c178181db3d0029074cae3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e653332f9579a414a62f5942265ccbe80eaba66a611b53394b8ac6d34007bac5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e653332f9579a414a62f5942265ccbe80eaba66a611b53394b8ac6d34007bac5->enter($__internal_e653332f9579a414a62f5942265ccbe80eaba66a611b53394b8ac6d34007bac5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        $__internal_a4e034a71537256caa2346240659b2ff54676b1d854d3d045d5b4a830ca94bdc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a4e034a71537256caa2346240659b2ff54676b1d854d3d045d5b4a830ca94bdc->enter($__internal_a4e034a71537256caa2346240659b2ff54676b1d854d3d045d5b4a830ca94bdc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_e653332f9579a414a62f5942265ccbe80eaba66a611b53394b8ac6d34007bac5->leave($__internal_e653332f9579a414a62f5942265ccbe80eaba66a611b53394b8ac6d34007bac5_prof);

        
        $__internal_a4e034a71537256caa2346240659b2ff54676b1d854d3d045d5b4a830ca94bdc->leave($__internal_a4e034a71537256caa2346240659b2ff54676b1d854d3d045d5b4a830ca94bdc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
", "@Framework/Form/choice_widget.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/choice_widget.html.php");
    }
}
