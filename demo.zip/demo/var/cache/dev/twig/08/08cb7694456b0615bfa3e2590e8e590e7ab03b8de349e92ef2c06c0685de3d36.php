<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_bdf9f6c9acae83aabafdd5889db3eeeb9bae52bddae06d856fdf7965bb0a1b9d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1973d367ddd4ad9ccac349e55791b917bb1739c16cae33f344e9467b91809dfb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1973d367ddd4ad9ccac349e55791b917bb1739c16cae33f344e9467b91809dfb->enter($__internal_1973d367ddd4ad9ccac349e55791b917bb1739c16cae33f344e9467b91809dfb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        $__internal_b1cb0b76840d01cb67b93cdfbca3491e2f1f21b348e2252179277946b3204f59 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b1cb0b76840d01cb67b93cdfbca3491e2f1f21b348e2252179277946b3204f59->enter($__internal_b1cb0b76840d01cb67b93cdfbca3491e2f1f21b348e2252179277946b3204f59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_1973d367ddd4ad9ccac349e55791b917bb1739c16cae33f344e9467b91809dfb->leave($__internal_1973d367ddd4ad9ccac349e55791b917bb1739c16cae33f344e9467b91809dfb_prof);

        
        $__internal_b1cb0b76840d01cb67b93cdfbca3491e2f1f21b348e2252179277946b3204f59->leave($__internal_b1cb0b76840d01cb67b93cdfbca3491e2f1f21b348e2252179277946b3204f59_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
", "@Framework/Form/email_widget.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/email_widget.html.php");
    }
}
