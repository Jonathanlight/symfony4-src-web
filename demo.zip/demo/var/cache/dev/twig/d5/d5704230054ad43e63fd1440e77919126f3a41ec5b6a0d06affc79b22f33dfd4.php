<?php

/* @Twig/Exception/error.json.twig */
class __TwigTemplate_8b3cdb8f8d2858d3e53911bd84fa1df3943f5a59e37634e9f605412d8f05e0b4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fe6009c596b8a3533336ff750d5a86b64e6dca15bf6cefec6cdb0099002b354a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fe6009c596b8a3533336ff750d5a86b64e6dca15bf6cefec6cdb0099002b354a->enter($__internal_fe6009c596b8a3533336ff750d5a86b64e6dca15bf6cefec6cdb0099002b354a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        $__internal_e2fc3faa2b1c01e232032430c1d77e9c542fd0aeb0305401b9a4248c74bfd87b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e2fc3faa2b1c01e232032430c1d77e9c542fd0aeb0305401b9a4248c74bfd87b->enter($__internal_e2fc3faa2b1c01e232032430c1d77e9c542fd0aeb0305401b9a4248c74bfd87b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        // line 1
        echo json_encode(array("error" => array("code" => (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 1, $this->getSourceContext()); })()), "message" => (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 1, $this->getSourceContext()); })()))));
        echo "
";
        
        $__internal_fe6009c596b8a3533336ff750d5a86b64e6dca15bf6cefec6cdb0099002b354a->leave($__internal_fe6009c596b8a3533336ff750d5a86b64e6dca15bf6cefec6cdb0099002b354a_prof);

        
        $__internal_e2fc3faa2b1c01e232032430c1d77e9c542fd0aeb0305401b9a4248c74bfd87b->leave($__internal_e2fc3faa2b1c01e232032430c1d77e9c542fd0aeb0305401b9a4248c74bfd87b_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "@Twig/Exception/error.json.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/twig-bundle/Resources/views/Exception/error.json.twig");
    }
}
