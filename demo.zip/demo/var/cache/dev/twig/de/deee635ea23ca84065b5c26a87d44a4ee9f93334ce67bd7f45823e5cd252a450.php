<?php

/* @Twig/Exception/error.css.twig */
class __TwigTemplate_25aa9a58b6be95312496b3ed4d63c44428cd3baf20dabbc718cfe3f24c67addb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ffeb3a63359db8c394173289d04a9746dd57b3b2d4fa80a467336db4e246fb6b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ffeb3a63359db8c394173289d04a9746dd57b3b2d4fa80a467336db4e246fb6b->enter($__internal_ffeb3a63359db8c394173289d04a9746dd57b3b2d4fa80a467336db4e246fb6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        $__internal_5453ff2a9033f80080b7ac4b3517bdf4fe897ec9afeb1f2c8c9ea11af1bd907f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5453ff2a9033f80080b7ac4b3517bdf4fe897ec9afeb1f2c8c9ea11af1bd907f->enter($__internal_5453ff2a9033f80080b7ac4b3517bdf4fe897ec9afeb1f2c8c9ea11af1bd907f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 2, $this->getSourceContext()); })()), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 2, $this->getSourceContext()); })()), "css", null, true);
        echo "

*/
";
        
        $__internal_ffeb3a63359db8c394173289d04a9746dd57b3b2d4fa80a467336db4e246fb6b->leave($__internal_ffeb3a63359db8c394173289d04a9746dd57b3b2d4fa80a467336db4e246fb6b_prof);

        
        $__internal_5453ff2a9033f80080b7ac4b3517bdf4fe897ec9afeb1f2c8c9ea11af1bd907f->leave($__internal_5453ff2a9033f80080b7ac4b3517bdf4fe897ec9afeb1f2c8c9ea11af1bd907f_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "@Twig/Exception/error.css.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/twig-bundle/Resources/views/Exception/error.css.twig");
    }
}
