<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_f7f3721f3afb1e4803c6e28e2a8f973ee5e16c2b66d0dbe9e0b2020492599031 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8bd858e4bbbe44a6417c756d7c03992567523dcc5f82d01a1e4fdf77c535dcc0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8bd858e4bbbe44a6417c756d7c03992567523dcc5f82d01a1e4fdf77c535dcc0->enter($__internal_8bd858e4bbbe44a6417c756d7c03992567523dcc5f82d01a1e4fdf77c535dcc0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        $__internal_876fb859e2a376f5c6d9b1be2864dcc64a5f76b9ac1c42d5aeb02feb352171b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_876fb859e2a376f5c6d9b1be2864dcc64a5f76b9ac1c42d5aeb02feb352171b6->enter($__internal_876fb859e2a376f5c6d9b1be2864dcc64a5f76b9ac1c42d5aeb02feb352171b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
";
        
        $__internal_8bd858e4bbbe44a6417c756d7c03992567523dcc5f82d01a1e4fdf77c535dcc0->leave($__internal_8bd858e4bbbe44a6417c756d7c03992567523dcc5f82d01a1e4fdf77c535dcc0_prof);

        
        $__internal_876fb859e2a376f5c6d9b1be2864dcc64a5f76b9ac1c42d5aeb02feb352171b6->leave($__internal_876fb859e2a376f5c6d9b1be2864dcc64a5f76b9ac1c42d5aeb02feb352171b6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/FormTable/button_row.html.php");
    }
}
