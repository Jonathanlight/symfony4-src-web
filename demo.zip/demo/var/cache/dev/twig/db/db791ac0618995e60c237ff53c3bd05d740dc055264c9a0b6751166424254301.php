<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_ac9f1332a2893e124177735dc80211a02f4c08cfb5699694676423f61f79c1b9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d1f91823cd8efaa08a31d18aa44c96cdca9edf16ce6ddd5a10f5a069dc8ef092 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d1f91823cd8efaa08a31d18aa44c96cdca9edf16ce6ddd5a10f5a069dc8ef092->enter($__internal_d1f91823cd8efaa08a31d18aa44c96cdca9edf16ce6ddd5a10f5a069dc8ef092_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        $__internal_629c9a943e6ad1da58632b8ff3687eb3b5b0699a322f5c78abf426a73dede4a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_629c9a943e6ad1da58632b8ff3687eb3b5b0699a322f5c78abf426a73dede4a2->enter($__internal_629c9a943e6ad1da58632b8ff3687eb3b5b0699a322f5c78abf426a73dede4a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_d1f91823cd8efaa08a31d18aa44c96cdca9edf16ce6ddd5a10f5a069dc8ef092->leave($__internal_d1f91823cd8efaa08a31d18aa44c96cdca9edf16ce6ddd5a10f5a069dc8ef092_prof);

        
        $__internal_629c9a943e6ad1da58632b8ff3687eb3b5b0699a322f5c78abf426a73dede4a2->leave($__internal_629c9a943e6ad1da58632b8ff3687eb3b5b0699a322f5c78abf426a73dede4a2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
", "@Framework/Form/form_errors.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/form_errors.html.php");
    }
}
