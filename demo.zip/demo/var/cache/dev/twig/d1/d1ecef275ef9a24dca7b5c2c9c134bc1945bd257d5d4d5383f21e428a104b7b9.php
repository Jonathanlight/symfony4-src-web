<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_6b768b336295ac05852ea9df0998b096ab8f721b90e5465c1e8807e958739822 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a7caf823d78fa3e548cab02ad488516e8c7990f99b86c3b26eb319330622dde7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a7caf823d78fa3e548cab02ad488516e8c7990f99b86c3b26eb319330622dde7->enter($__internal_a7caf823d78fa3e548cab02ad488516e8c7990f99b86c3b26eb319330622dde7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_2edbbe8d0b3b3bf4107fb5f695730628130e44d90625377ad9913b1bc1225b17 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2edbbe8d0b3b3bf4107fb5f695730628130e44d90625377ad9913b1bc1225b17->enter($__internal_2edbbe8d0b3b3bf4107fb5f695730628130e44d90625377ad9913b1bc1225b17_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_a7caf823d78fa3e548cab02ad488516e8c7990f99b86c3b26eb319330622dde7->leave($__internal_a7caf823d78fa3e548cab02ad488516e8c7990f99b86c3b26eb319330622dde7_prof);

        
        $__internal_2edbbe8d0b3b3bf4107fb5f695730628130e44d90625377ad9913b1bc1225b17->leave($__internal_2edbbe8d0b3b3bf4107fb5f695730628130e44d90625377ad9913b1bc1225b17_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/form_enctype.html.php");
    }
}
