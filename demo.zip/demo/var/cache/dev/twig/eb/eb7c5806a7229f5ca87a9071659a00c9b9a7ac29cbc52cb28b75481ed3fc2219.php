<?php

/* @WebProfiler/Collector/exception.css.twig */
class __TwigTemplate_656b116007d1be6d2c29f698f772c16270309b267a0bb9eeaeee834bd250ac6b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dba5341b193131f1d090e477953883a0abb3e0f25e94eeea021c2a9cda9adc2c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dba5341b193131f1d090e477953883a0abb3e0f25e94eeea021c2a9cda9adc2c->enter($__internal_dba5341b193131f1d090e477953883a0abb3e0f25e94eeea021c2a9cda9adc2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.css.twig"));

        $__internal_31137f1e7b2fb55e01bf797c18735ac739bff2649041e3bb9e143ffe3a747491 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_31137f1e7b2fb55e01bf797c18735ac739bff2649041e3bb9e143ffe3a747491->enter($__internal_31137f1e7b2fb55e01bf797c18735ac739bff2649041e3bb9e143ffe3a747491_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.css.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "

.container {
    max-width: auto;
    margin: 0;
    padding: 0;
}
.container .container {
    padding: 0;
}

.exception-summary {
    background: #FFF;
    border: 1px solid #E0E0E0;
    box-shadow: 0 0 1px rgba(128, 128, 128, .2);
    margin: 1em 0;
    padding: 10px;
}
.exception-summary.exception-without-message {
    display: none;
}

.exception-message {
    color: #B0413E;
}

.exception-metadata,
.exception-illustration {
    display: none;
}

.exception-message-wrapper .container {
    min-height: auto;
}
";
        
        $__internal_dba5341b193131f1d090e477953883a0abb3e0f25e94eeea021c2a9cda9adc2c->leave($__internal_dba5341b193131f1d090e477953883a0abb3e0f25e94eeea021c2a9cda9adc2c_prof);

        
        $__internal_31137f1e7b2fb55e01bf797c18735ac739bff2649041e3bb9e143ffe3a747491->leave($__internal_31137f1e7b2fb55e01bf797c18735ac739bff2649041e3bb9e143ffe3a747491_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/exception.css.twig') }}

.container {
    max-width: auto;
    margin: 0;
    padding: 0;
}
.container .container {
    padding: 0;
}

.exception-summary {
    background: #FFF;
    border: 1px solid #E0E0E0;
    box-shadow: 0 0 1px rgba(128, 128, 128, .2);
    margin: 1em 0;
    padding: 10px;
}
.exception-summary.exception-without-message {
    display: none;
}

.exception-message {
    color: #B0413E;
}

.exception-metadata,
.exception-illustration {
    display: none;
}

.exception-message-wrapper .container {
    min-height: auto;
}
", "@WebProfiler/Collector/exception.css.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/web-profiler-bundle/Resources/views/Collector/exception.css.twig");
    }
}
