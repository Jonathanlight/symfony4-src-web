<?php

/* @Framework/Form/form_label.html.php */
class __TwigTemplate_8ca7cbe26be3525418853e9fd46702e7d9bcf47cd3557f22150b860b592ff72a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a9477b733e8ea6f458f3accde899c5e26cef4d120cb4c57fd125ef03d15f26bc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a9477b733e8ea6f458f3accde899c5e26cef4d120cb4c57fd125ef03d15f26bc->enter($__internal_a9477b733e8ea6f458f3accde899c5e26cef4d120cb4c57fd125ef03d15f26bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_label.html.php"));

        $__internal_f2ccdee2590863a7c1f7335264121c1fc6472ec7fd86567a70537e1b324de916 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f2ccdee2590863a7c1f7335264121c1fc6472ec7fd86567a70537e1b324de916->enter($__internal_f2ccdee2590863a7c1f7335264121c1fc6472ec7fd86567a70537e1b324de916_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_label.html.php"));

        // line 1
        echo "<?php if (false !== \$label): ?>
<?php if (\$required) { \$label_attr['class'] = trim((isset(\$label_attr['class']) ? \$label_attr['class'] : '').' required'); } ?>
<?php if (!\$compound) { \$label_attr['for'] = \$id; } ?>
<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<label<?php if (\$label_attr) { echo ' '.\$view['form']->block(\$form, 'attributes', array('attr' => \$label_attr)); } ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></label>
<?php endif ?>
";
        
        $__internal_a9477b733e8ea6f458f3accde899c5e26cef4d120cb4c57fd125ef03d15f26bc->leave($__internal_a9477b733e8ea6f458f3accde899c5e26cef4d120cb4c57fd125ef03d15f26bc_prof);

        
        $__internal_f2ccdee2590863a7c1f7335264121c1fc6472ec7fd86567a70537e1b324de916->leave($__internal_f2ccdee2590863a7c1f7335264121c1fc6472ec7fd86567a70537e1b324de916_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_label.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (false !== \$label): ?>
<?php if (\$required) { \$label_attr['class'] = trim((isset(\$label_attr['class']) ? \$label_attr['class'] : '').' required'); } ?>
<?php if (!\$compound) { \$label_attr['for'] = \$id; } ?>
<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<label<?php if (\$label_attr) { echo ' '.\$view['form']->block(\$form, 'attributes', array('attr' => \$label_attr)); } ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></label>
<?php endif ?>
", "@Framework/Form/form_label.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/form_label.html.php");
    }
}
