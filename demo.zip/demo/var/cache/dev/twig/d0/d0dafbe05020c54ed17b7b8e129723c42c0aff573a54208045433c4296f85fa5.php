<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_6c36237c6573cab98c546792e9719f8a29c89ad65bf5224e4dfadf6d32400067 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_776e2cbcf2e97571654d6620c21958645b25ecd256783765cd4e86e699b35a59 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_776e2cbcf2e97571654d6620c21958645b25ecd256783765cd4e86e699b35a59->enter($__internal_776e2cbcf2e97571654d6620c21958645b25ecd256783765cd4e86e699b35a59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        $__internal_6b9d536246918faeaabee136165379f90d5ceb65e9bf1409ec05e0fc8f9eab79 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6b9d536246918faeaabee136165379f90d5ceb65e9bf1409ec05e0fc8f9eab79->enter($__internal_6b9d536246918faeaabee136165379f90d5ceb65e9bf1409ec05e0fc8f9eab79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form); ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form); ?>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
";
        
        $__internal_776e2cbcf2e97571654d6620c21958645b25ecd256783765cd4e86e699b35a59->leave($__internal_776e2cbcf2e97571654d6620c21958645b25ecd256783765cd4e86e699b35a59_prof);

        
        $__internal_6b9d536246918faeaabee136165379f90d5ceb65e9bf1409ec05e0fc8f9eab79->leave($__internal_6b9d536246918faeaabee136165379f90d5ceb65e9bf1409ec05e0fc8f9eab79_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td>
        <?php echo \$view['form']->label(\$form); ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form); ?>
        <?php echo \$view['form']->widget(\$form); ?>
    </td>
</tr>
", "@Framework/FormTable/form_row.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/FormTable/form_row.html.php");
    }
}
