<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_a7f009189ecc9864a4f677e329cfe762f8b45d7c2f51a5986500c41b26877909 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9be5a33e3be4b8fe67d04f330c994389613af2cbd51bc22d132c14830edc4c78 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9be5a33e3be4b8fe67d04f330c994389613af2cbd51bc22d132c14830edc4c78->enter($__internal_9be5a33e3be4b8fe67d04f330c994389613af2cbd51bc22d132c14830edc4c78_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        $__internal_1de91f862ab2eacf922fa9a0313a3bf9163697aaee7242d9ad09f3973c9621a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1de91f862ab2eacf922fa9a0313a3bf9163697aaee7242d9ad09f3973c9621a2->enter($__internal_1de91f862ab2eacf922fa9a0313a3bf9163697aaee7242d9ad09f3973c9621a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_9be5a33e3be4b8fe67d04f330c994389613af2cbd51bc22d132c14830edc4c78->leave($__internal_9be5a33e3be4b8fe67d04f330c994389613af2cbd51bc22d132c14830edc4c78_prof);

        
        $__internal_1de91f862ab2eacf922fa9a0313a3bf9163697aaee7242d9ad09f3973c9621a2->leave($__internal_1de91f862ab2eacf922fa9a0313a3bf9163697aaee7242d9ad09f3973c9621a2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'submit')) ?>
", "@Framework/Form/submit_widget.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/submit_widget.html.php");
    }
}
