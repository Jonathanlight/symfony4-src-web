<?php

/* @WebProfiler/Icon/forward.svg */
class __TwigTemplate_540719dc7a74956799b97e84a0979f642ac9a114894cdee1976f0e76f10410e2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fd2cd77524dc70c6fc1b7741e305129e1252d3c5e618f6b3fa24e27ec15aa030 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fd2cd77524dc70c6fc1b7741e305129e1252d3c5e618f6b3fa24e27ec15aa030->enter($__internal_fd2cd77524dc70c6fc1b7741e305129e1252d3c5e618f6b3fa24e27ec15aa030_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/forward.svg"));

        $__internal_271dbf215e5b623451d9bc119b16c1600984ebd75264c6dd4df029f0f642c777 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_271dbf215e5b623451d9bc119b16c1600984ebd75264c6dd4df029f0f642c777->enter($__internal_271dbf215e5b623451d9bc119b16c1600984ebd75264c6dd4df029f0f642c777_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Icon/forward.svg"));

        // line 1
        echo "<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
    <path style=\"fill:#aaa\" d=\"M23.61,11.07L17.07,4.35A1.2,1.2,0,0,0,15,5.28V9H1.4A1.82,1.82,0,0,0,0,10.82v2.61A1.55,
        1.55,0,0,0,1.4,15H15v3.72a1.2,1.2,0,0,0,2.07.93l6.63-6.72A1.32,1.32,0,0,0,23.61,11.07Z\"/>
</svg>
";
        
        $__internal_fd2cd77524dc70c6fc1b7741e305129e1252d3c5e618f6b3fa24e27ec15aa030->leave($__internal_fd2cd77524dc70c6fc1b7741e305129e1252d3c5e618f6b3fa24e27ec15aa030_prof);

        
        $__internal_271dbf215e5b623451d9bc119b16c1600984ebd75264c6dd4df029f0f642c777->leave($__internal_271dbf215e5b623451d9bc119b16c1600984ebd75264c6dd4df029f0f642c777_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Icon/forward.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
    <path style=\"fill:#aaa\" d=\"M23.61,11.07L17.07,4.35A1.2,1.2,0,0,0,15,5.28V9H1.4A1.82,1.82,0,0,0,0,10.82v2.61A1.55,
        1.55,0,0,0,1.4,15H15v3.72a1.2,1.2,0,0,0,2.07.93l6.63-6.72A1.32,1.32,0,0,0,23.61,11.07Z\"/>
</svg>
", "@WebProfiler/Icon/forward.svg", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/web-profiler-bundle/Resources/views/Icon/forward.svg");
    }
}
