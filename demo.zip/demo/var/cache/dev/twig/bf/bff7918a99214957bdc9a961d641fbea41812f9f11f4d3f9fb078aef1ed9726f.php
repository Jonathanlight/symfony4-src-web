<?php

/* @Twig/Exception/exception.atom.twig */
class __TwigTemplate_37c4d5b97e35dceea0e6caff2cd6aa94d8a959437f475265279b5aff67fa31d7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8ab6a56c294387d2635762bc39eee497e5ab588584cba630bf598870f4458669 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8ab6a56c294387d2635762bc39eee497e5ab588584cba630bf598870f4458669->enter($__internal_8ab6a56c294387d2635762bc39eee497e5ab588584cba630bf598870f4458669_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        $__internal_9fff52d42c7074337399af211ae2544fef93681a5ea46cadc62cb84677742e12 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9fff52d42c7074337399af211ae2544fef93681a5ea46cadc62cb84677742e12->enter($__internal_9fff52d42c7074337399af211ae2544fef93681a5ea46cadc62cb84677742e12_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        // line 1
        echo twig_include($this->env, $context, "@Twig/Exception/exception.xml.twig", array("exception" => (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 1, $this->getSourceContext()); })())));
        echo "
";
        
        $__internal_8ab6a56c294387d2635762bc39eee497e5ab588584cba630bf598870f4458669->leave($__internal_8ab6a56c294387d2635762bc39eee497e5ab588584cba630bf598870f4458669_prof);

        
        $__internal_9fff52d42c7074337399af211ae2544fef93681a5ea46cadc62cb84677742e12->leave($__internal_9fff52d42c7074337399af211ae2544fef93681a5ea46cadc62cb84677742e12_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('@Twig/Exception/exception.xml.twig', { exception: exception }) }}
", "@Twig/Exception/exception.atom.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/twig-bundle/Resources/views/Exception/exception.atom.twig");
    }
}
