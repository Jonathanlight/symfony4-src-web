<?php

/* page/home.html.twig */
class __TwigTemplate_dd8fc93ce7e15f5988bf640c8b31f488cd09058bd34121da57de14af36595bad extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "page/home.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3a12b5a81509b4ff4df793d40951e5a3c14933815f1f14f59a843becf3328113 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3a12b5a81509b4ff4df793d40951e5a3c14933815f1f14f59a843becf3328113->enter($__internal_3a12b5a81509b4ff4df793d40951e5a3c14933815f1f14f59a843becf3328113_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "page/home.html.twig"));

        $__internal_b70ad018221c2338e7e3e4784bee5fff8025c338843e0c0e90241bb0d9c982cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b70ad018221c2338e7e3e4784bee5fff8025c338843e0c0e90241bb0d9c982cb->enter($__internal_b70ad018221c2338e7e3e4784bee5fff8025c338843e0c0e90241bb0d9c982cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "page/home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3a12b5a81509b4ff4df793d40951e5a3c14933815f1f14f59a843becf3328113->leave($__internal_3a12b5a81509b4ff4df793d40951e5a3c14933815f1f14f59a843becf3328113_prof);

        
        $__internal_b70ad018221c2338e7e3e4784bee5fff8025c338843e0c0e90241bb0d9c982cb->leave($__internal_b70ad018221c2338e7e3e4784bee5fff8025c338843e0c0e90241bb0d9c982cb_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_6d63f1c772c61124adda0b0c2ab4b491daeed13359acbc80b1f04f2e43b5561c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6d63f1c772c61124adda0b0c2ab4b491daeed13359acbc80b1f04f2e43b5561c->enter($__internal_6d63f1c772c61124adda0b0c2ab4b491daeed13359acbc80b1f04f2e43b5561c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f654456d316c68f345fb080d9343e9fa272fd193d7abe0e749303d80428d26f3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f654456d316c68f345fb080d9343e9fa272fd193d7abe0e749303d80428d26f3->enter($__internal_f654456d316c68f345fb080d9343e9fa272fd193d7abe0e749303d80428d26f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
<div class=\"container\">
    ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new Twig_Error_Runtime('Variable "app" does not exist.', 6, $this->getSourceContext()); })()), "flashes", array(0 => "notice"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 7
            echo "    <div class='alert alert-notice'>
        ";
            // line 8
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "
    </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 11
        echo "
    <div class=\"starter-template\">
        <h1>List Product</h1>
    </div>

    <div class=\"table-responsive\">
        <table class=\"table table-striped\">
            <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Price</th>
                <th>Description</th>
                <th>Description</th>
            </tr>
            </thead>
            <tbody>
            ";
        // line 28
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reponses"]) || array_key_exists("reponses", $context) ? $context["reponses"] : (function () { throw new Twig_Error_Runtime('Variable "reponses" does not exist.', 28, $this->getSourceContext()); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["reponse"]) {
            // line 29
            echo "            <tr>
                <td>";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["reponse"], "id", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["reponse"], "name", array()), "html", null, true);
            echo " </td>
                <td>";
            // line 32
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["reponse"], "price", array()), "html", null, true);
            echo " euro</td>
                <td>";
            // line 33
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->getSourceContext(), $context["reponse"], "description", array()), "html", null, true);
            echo "</td>
                <td>
                    <a href=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("edit", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), $context["reponse"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-primary\">Edit</a>
                    <a href=\"";
            // line 36
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("delete", array("id" => twig_get_attribute($this->env, $this->getSourceContext(), $context["reponse"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-danger\">Delete</a>
                </td>
            </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['reponse'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 40
        echo "            </tbody>
        </table>
    </div>


    <div class=\"starter-template\">
        <h1>Formulaire</h1>
    </div>

    <ul class=\"well\">
        ";
        // line 50
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 50, $this->getSourceContext()); })()), 'form_start', array("attr" => array("class" => "form-horizontal")));
        echo "
        ";
        // line 51
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 51, $this->getSourceContext()); })()), "name", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "Name product")));
        echo "
        ";
        // line 52
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 52, $this->getSourceContext()); })()), "price", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "Price product")));
        echo "
        ";
        // line 53
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 53, $this->getSourceContext()); })()), "description", array()), 'row', array("attr" => array("class" => "form-control", "placeholder" => "Description product")));
        echo "
        ";
        // line 54
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 54, $this->getSourceContext()); })()), "save", array()), 'row', array("attr" => array("class" => "btn btn-success")));
        echo "
        ";
        // line 55
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 55, $this->getSourceContext()); })()), 'form_end');
        echo "
    </ul>

</div>
";
        
        $__internal_f654456d316c68f345fb080d9343e9fa272fd193d7abe0e749303d80428d26f3->leave($__internal_f654456d316c68f345fb080d9343e9fa272fd193d7abe0e749303d80428d26f3_prof);

        
        $__internal_6d63f1c772c61124adda0b0c2ab4b491daeed13359acbc80b1f04f2e43b5561c->leave($__internal_6d63f1c772c61124adda0b0c2ab4b491daeed13359acbc80b1f04f2e43b5561c_prof);

    }

    public function getTemplateName()
    {
        return "page/home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  160 => 55,  156 => 54,  152 => 53,  148 => 52,  144 => 51,  140 => 50,  128 => 40,  118 => 36,  114 => 35,  109 => 33,  105 => 32,  101 => 31,  97 => 30,  94 => 29,  90 => 28,  71 => 11,  62 => 8,  59 => 7,  55 => 6,  49 => 4,  40 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
    {{ parent() }}
<div class=\"container\">
    {% for message in app.flashes('notice') %}
    <div class='alert alert-notice'>
        {{ message }}
    </div>
    {% endfor %}

    <div class=\"starter-template\">
        <h1>List Product</h1>
    </div>

    <div class=\"table-responsive\">
        <table class=\"table table-striped\">
            <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Price</th>
                <th>Description</th>
                <th>Description</th>
            </tr>
            </thead>
            <tbody>
            {% for reponse in reponses %}
            <tr>
                <td>{{ reponse.id }}</td>
                <td>{{ reponse.name }} </td>
                <td>{{ reponse.price }} euro</td>
                <td>{{ reponse.description }}</td>
                <td>
                    <a href=\"{{ url('edit', {'id': reponse.id }) }}\" class=\"btn btn-primary\">Edit</a>
                    <a href=\"{{ url('delete', {'id': reponse.id }) }}\" class=\"btn btn-danger\">Delete</a>
                </td>
            </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>


    <div class=\"starter-template\">
        <h1>Formulaire</h1>
    </div>

    <ul class=\"well\">
        {{ form_start(form, {'attr': {'class': 'form-horizontal'}}) }}
        {{ form_row(form.name, {'attr': {'class': 'form-control', 'placeholder':'Name product'}}) }}
        {{ form_row(form.price, {'attr': {'class': 'form-control', 'placeholder':'Price product'}}) }}
        {{ form_row(form.description, {'attr': {'class': 'form-control', 'placeholder':'Description product'}}) }}
        {{ form_row(form.save, {'attr': {'class': 'btn btn-success'}}) }}
        {{ form_end(form) }}
    </ul>

</div>
{% endblock %}


", "page/home.html.twig", "/Users/admin/Desktop/Work/Jonathan/demo/src/Resources/views/page/home.html.twig");
    }
}
