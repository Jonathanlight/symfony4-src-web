<?php

/* @Framework/Form/choice_attributes.html.php */
class __TwigTemplate_5b5cb5f851f16a8bb0f93d9264564c35a57e03c61563b257a8e4fff93aa13b05 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0aa10cd9ddf2be01da1bd368e094e1089325ffa9d2853885573e6f019bba0fc1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0aa10cd9ddf2be01da1bd368e094e1089325ffa9d2853885573e6f019bba0fc1->enter($__internal_0aa10cd9ddf2be01da1bd368e094e1089325ffa9d2853885573e6f019bba0fc1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        $__internal_505063aec9dc21cde6bd165f81b5baa8bbf97abb480b96913e57533a4227c8cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_505063aec9dc21cde6bd165f81b5baa8bbf97abb480b96913e57533a4227c8cc->enter($__internal_505063aec9dc21cde6bd165f81b5baa8bbf97abb480b96913e57533a4227c8cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        // line 1
        echo "<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
";
        
        $__internal_0aa10cd9ddf2be01da1bd368e094e1089325ffa9d2853885573e6f019bba0fc1->leave($__internal_0aa10cd9ddf2be01da1bd368e094e1089325ffa9d2853885573e6f019bba0fc1_prof);

        
        $__internal_505063aec9dc21cde6bd165f81b5baa8bbf97abb480b96913e57533a4227c8cc->leave($__internal_505063aec9dc21cde6bd165f81b5baa8bbf97abb480b96913e57533a4227c8cc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
", "@Framework/Form/choice_attributes.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/choice_attributes.html.php");
    }
}
