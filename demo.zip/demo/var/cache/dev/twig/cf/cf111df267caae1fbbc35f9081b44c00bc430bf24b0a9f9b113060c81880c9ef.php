<?php

/* @WebProfiler/Profiler/toolbar_redirect.html.twig */
class __TwigTemplate_6321655045ab27013ae4d07834b36bc60826fbe5ec5a39e40d0e35d427b26301 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@WebProfiler/Profiler/toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b256b7981a000508e160fc3d3f65dfbea3666d56a745064d139b33b2a9d7a6a7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b256b7981a000508e160fc3d3f65dfbea3666d56a745064d139b33b2a9d7a6a7->enter($__internal_b256b7981a000508e160fc3d3f65dfbea3666d56a745064d139b33b2a9d7a6a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $__internal_31a7ebcbcd6d356a64d300652b7f99b5cf751797de60a01d3e5946809cd3432e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_31a7ebcbcd6d356a64d300652b7f99b5cf751797de60a01d3e5946809cd3432e->enter($__internal_31a7ebcbcd6d356a64d300652b7f99b5cf751797de60a01d3e5946809cd3432e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b256b7981a000508e160fc3d3f65dfbea3666d56a745064d139b33b2a9d7a6a7->leave($__internal_b256b7981a000508e160fc3d3f65dfbea3666d56a745064d139b33b2a9d7a6a7_prof);

        
        $__internal_31a7ebcbcd6d356a64d300652b7f99b5cf751797de60a01d3e5946809cd3432e->leave($__internal_31a7ebcbcd6d356a64d300652b7f99b5cf751797de60a01d3e5946809cd3432e_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_3bb3e74f8e17d7d8bc66b65888a9d55f92822bda876afa4591d584fc60559903 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3bb3e74f8e17d7d8bc66b65888a9d55f92822bda876afa4591d584fc60559903->enter($__internal_3bb3e74f8e17d7d8bc66b65888a9d55f92822bda876afa4591d584fc60559903_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_2ba446971be4fa0209c382289760b6274def80306db73fd5616dd41590ad2f8a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2ba446971be4fa0209c382289760b6274def80306db73fd5616dd41590ad2f8a->enter($__internal_2ba446971be4fa0209c382289760b6274def80306db73fd5616dd41590ad2f8a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_2ba446971be4fa0209c382289760b6274def80306db73fd5616dd41590ad2f8a->leave($__internal_2ba446971be4fa0209c382289760b6274def80306db73fd5616dd41590ad2f8a_prof);

        
        $__internal_3bb3e74f8e17d7d8bc66b65888a9d55f92822bda876afa4591d584fc60559903->leave($__internal_3bb3e74f8e17d7d8bc66b65888a9d55f92822bda876afa4591d584fc60559903_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_8801b04176fa90d3f944ed910bd213d5c92cc4bdbaa36ff31bf4bafdf3d9704a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8801b04176fa90d3f944ed910bd213d5c92cc4bdbaa36ff31bf4bafdf3d9704a->enter($__internal_8801b04176fa90d3f944ed910bd213d5c92cc4bdbaa36ff31bf4bafdf3d9704a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_45615fc7fefe17692b710fab672c5253e4d642789f6a0effbd74de22c0b573b5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_45615fc7fefe17692b710fab672c5253e4d642789f6a0effbd74de22c0b573b5->enter($__internal_45615fc7fefe17692b710fab672c5253e4d642789f6a0effbd74de22c0b573b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) || array_key_exists("location", $context) ? $context["location"] : (function () { throw new Twig_Error_Runtime('Variable "location" does not exist.', 8, $this->getSourceContext()); })()), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) || array_key_exists("location", $context) ? $context["location"] : (function () { throw new Twig_Error_Runtime('Variable "location" does not exist.', 8, $this->getSourceContext()); })()), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_45615fc7fefe17692b710fab672c5253e4d642789f6a0effbd74de22c0b573b5->leave($__internal_45615fc7fefe17692b710fab672c5253e4d642789f6a0effbd74de22c0b573b5_prof);

        
        $__internal_8801b04176fa90d3f944ed910bd213d5c92cc4bdbaa36ff31bf4bafdf3d9704a->leave($__internal_8801b04176fa90d3f944ed910bd213d5c92cc4bdbaa36ff31bf4bafdf3d9704a_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "@WebProfiler/Profiler/toolbar_redirect.html.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/web-profiler-bundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
