<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_ecea30e291f8540c503e6262a97c8940af94c65df82d20fd27bc91a9835442b1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9f30239cad4f43aefc7e93ede95de6a68e7d4d8d688c5b365fad4f2ae7baf9e2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9f30239cad4f43aefc7e93ede95de6a68e7d4d8d688c5b365fad4f2ae7baf9e2->enter($__internal_9f30239cad4f43aefc7e93ede95de6a68e7d4d8d688c5b365fad4f2ae7baf9e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        $__internal_5374cb11bda575f9707a741ec86781c6ba5a2623b84902f6d4fb2693f68b0249 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5374cb11bda575f9707a741ec86781c6ba5a2623b84902f6d4fb2693f68b0249->enter($__internal_5374cb11bda575f9707a741ec86781c6ba5a2623b84902f6d4fb2693f68b0249_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_9f30239cad4f43aefc7e93ede95de6a68e7d4d8d688c5b365fad4f2ae7baf9e2->leave($__internal_9f30239cad4f43aefc7e93ede95de6a68e7d4d8d688c5b365fad4f2ae7baf9e2_prof);

        
        $__internal_5374cb11bda575f9707a741ec86781c6ba5a2623b84902f6d4fb2693f68b0249->leave($__internal_5374cb11bda575f9707a741ec86781c6ba5a2623b84902f6d4fb2693f68b0249_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
", "@Framework/Form/search_widget.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/search_widget.html.php");
    }
}
