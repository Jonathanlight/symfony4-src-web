<?php

/* @Twig/Exception/error.txt.twig */
class __TwigTemplate_e41c7ef66f7aa8e88eb836ab3a036df7d66e620b70f99cad7015cfbb0ab59445 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_30941b283a1370dfcabfd6667f81028759308946cf39e4fe4ed04ea595aa651c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_30941b283a1370dfcabfd6667f81028759308946cf39e4fe4ed04ea595aa651c->enter($__internal_30941b283a1370dfcabfd6667f81028759308946cf39e4fe4ed04ea595aa651c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.txt.twig"));

        $__internal_4e93686b48f7e2d8713b695f60114499cf1e8f7f0171a6373272d694c88a3fc4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4e93686b48f7e2d8713b695f60114499cf1e8f7f0171a6373272d694c88a3fc4->enter($__internal_4e93686b48f7e2d8713b695f60114499cf1e8f7f0171a6373272d694c88a3fc4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 4, $this->getSourceContext()); })());
        echo " ";
        echo (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 4, $this->getSourceContext()); })());
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_30941b283a1370dfcabfd6667f81028759308946cf39e4fe4ed04ea595aa651c->leave($__internal_30941b283a1370dfcabfd6667f81028759308946cf39e4fe4ed04ea595aa651c_prof);

        
        $__internal_4e93686b48f7e2d8713b695f60114499cf1e8f7f0171a6373272d694c88a3fc4->leave($__internal_4e93686b48f7e2d8713b695f60114499cf1e8f7f0171a6373272d694c88a3fc4_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 4,  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("Oops! An Error Occurred
=======================

The server returned a \"{{ status_code }} {{ status_text }}\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
", "@Twig/Exception/error.txt.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/twig-bundle/Resources/views/Exception/error.txt.twig");
    }
}
