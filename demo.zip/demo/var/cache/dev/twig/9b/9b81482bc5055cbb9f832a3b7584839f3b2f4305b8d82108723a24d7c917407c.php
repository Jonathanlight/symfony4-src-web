<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_f8d5c883644e7f94a322b8aee3a96582e3f4340fced78f9b4bab1903916eff28 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ce13da85b6e024823db68611c0e2aac695ffce8564a17fc635ed84120b393f77 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ce13da85b6e024823db68611c0e2aac695ffce8564a17fc635ed84120b393f77->enter($__internal_ce13da85b6e024823db68611c0e2aac695ffce8564a17fc635ed84120b393f77_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        $__internal_139d140f64aa626a9e1813c29306ef410f3f5c7bc4e2233c2be8f1bad7fb09de = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_139d140f64aa626a9e1813c29306ef410f3f5c7bc4e2233c2be8f1bad7fb09de->enter($__internal_139d140f64aa626a9e1813c29306ef410f3f5c7bc4e2233c2be8f1bad7fb09de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_ce13da85b6e024823db68611c0e2aac695ffce8564a17fc635ed84120b393f77->leave($__internal_ce13da85b6e024823db68611c0e2aac695ffce8564a17fc635ed84120b393f77_prof);

        
        $__internal_139d140f64aa626a9e1813c29306ef410f3f5c7bc4e2233c2be8f1bad7fb09de->leave($__internal_139d140f64aa626a9e1813c29306ef410f3f5c7bc4e2233c2be8f1bad7fb09de_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
", "@Framework/Form/url_widget.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/url_widget.html.php");
    }
}
