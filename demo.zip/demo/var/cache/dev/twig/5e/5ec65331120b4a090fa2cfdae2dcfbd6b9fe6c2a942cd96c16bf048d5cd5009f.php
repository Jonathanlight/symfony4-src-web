<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_a1652ea544a2b874fa4faad2afea46a63683efeec8babd8b8e7320e7d13333d4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8f52685d134dc25d776fe93bb4076170805c18baa63498183a4eca15eacca240 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8f52685d134dc25d776fe93bb4076170805c18baa63498183a4eca15eacca240->enter($__internal_8f52685d134dc25d776fe93bb4076170805c18baa63498183a4eca15eacca240_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        $__internal_8c6e7cb69299f2f52fa6a417a89a38fed037f2c4087434bfdd6a9ca42cd4b52f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8c6e7cb69299f2f52fa6a417a89a38fed037f2c4087434bfdd6a9ca42cd4b52f->enter($__internal_8c6e7cb69299f2f52fa6a417a89a38fed037f2c4087434bfdd6a9ca42cd4b52f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_8f52685d134dc25d776fe93bb4076170805c18baa63498183a4eca15eacca240->leave($__internal_8f52685d134dc25d776fe93bb4076170805c18baa63498183a4eca15eacca240_prof);

        
        $__internal_8c6e7cb69299f2f52fa6a417a89a38fed037f2c4087434bfdd6a9ca42cd4b52f->leave($__internal_8c6e7cb69299f2f52fa6a417a89a38fed037f2c4087434bfdd6a9ca42cd4b52f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
", "@Framework/Form/form_rows.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/form_rows.html.php");
    }
}
