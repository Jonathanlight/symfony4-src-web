<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_35e81178af8507fe042e203a99d0629b0bfb48e22b992db92ad17feccb788f7d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7929ab5cf732c000823acdcefc03eb3abf454bc51f5fa032bafc6fbd2dce7b0f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7929ab5cf732c000823acdcefc03eb3abf454bc51f5fa032bafc6fbd2dce7b0f->enter($__internal_7929ab5cf732c000823acdcefc03eb3abf454bc51f5fa032bafc6fbd2dce7b0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        $__internal_3441c6b1a1b64e19e49217286d522695fbdb24c65c520e2d9ad20ea594e08894 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3441c6b1a1b64e19e49217286d522695fbdb24c65c520e2d9ad20ea594e08894->enter($__internal_3441c6b1a1b64e19e49217286d522695fbdb24c65c520e2d9ad20ea594e08894_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_7929ab5cf732c000823acdcefc03eb3abf454bc51f5fa032bafc6fbd2dce7b0f->leave($__internal_7929ab5cf732c000823acdcefc03eb3abf454bc51f5fa032bafc6fbd2dce7b0f_prof);

        
        $__internal_3441c6b1a1b64e19e49217286d522695fbdb24c65c520e2d9ad20ea594e08894->leave($__internal_3441c6b1a1b64e19e49217286d522695fbdb24c65c520e2d9ad20ea594e08894_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
", "@Framework/Form/form_end.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/form_end.html.php");
    }
}
