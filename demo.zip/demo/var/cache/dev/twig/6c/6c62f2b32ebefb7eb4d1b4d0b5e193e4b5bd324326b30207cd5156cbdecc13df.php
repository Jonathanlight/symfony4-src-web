<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_0e9993e2c60a58bea7ae051523a7444ac56ca33a76c04b699a63572a98e62a2a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ae33008862e63f4ddc4aff771c5a28a8a8434931315e2a014f5013007b7c5a20 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ae33008862e63f4ddc4aff771c5a28a8a8434931315e2a014f5013007b7c5a20->enter($__internal_ae33008862e63f4ddc4aff771c5a28a8a8434931315e2a014f5013007b7c5a20_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        $__internal_6d8c91cff449a1b65e375f8c0eb8e9aecf664dfc564d5b74fae247c52858bf88 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6d8c91cff449a1b65e375f8c0eb8e9aecf664dfc564d5b74fae247c52858bf88->enter($__internal_6d8c91cff449a1b65e375f8c0eb8e9aecf664dfc564d5b74fae247c52858bf88_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_ae33008862e63f4ddc4aff771c5a28a8a8434931315e2a014f5013007b7c5a20->leave($__internal_ae33008862e63f4ddc4aff771c5a28a8a8434931315e2a014f5013007b7c5a20_prof);

        
        $__internal_6d8c91cff449a1b65e375f8c0eb8e9aecf664dfc564d5b74fae247c52858bf88->leave($__internal_6d8c91cff449a1b65e375f8c0eb8e9aecf664dfc564d5b74fae247c52858bf88_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/form_row.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/form_row.html.php");
    }
}
