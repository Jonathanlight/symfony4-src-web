<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_a076c32b860981d81efdfc119d09941b3a4e40eb9e1350f2c5a90eba53abbdb1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2f129567e6f580cb87cd44a354c851adfe264441f0e913f65ddaa67637a92f76 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2f129567e6f580cb87cd44a354c851adfe264441f0e913f65ddaa67637a92f76->enter($__internal_2f129567e6f580cb87cd44a354c851adfe264441f0e913f65ddaa67637a92f76_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        $__internal_a6201cb1acd13576d9f26ca23b6760f22751ae5fa9c3b0143a994ac2b16395df = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a6201cb1acd13576d9f26ca23b6760f22751ae5fa9c3b0143a994ac2b16395df->enter($__internal_a6201cb1acd13576d9f26ca23b6760f22751ae5fa9c3b0143a994ac2b16395df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_2f129567e6f580cb87cd44a354c851adfe264441f0e913f65ddaa67637a92f76->leave($__internal_2f129567e6f580cb87cd44a354c851adfe264441f0e913f65ddaa67637a92f76_prof);

        
        $__internal_a6201cb1acd13576d9f26ca23b6760f22751ae5fa9c3b0143a994ac2b16395df->leave($__internal_a6201cb1acd13576d9f26ca23b6760f22751ae5fa9c3b0143a994ac2b16395df_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/framework-bundle/Resources/views/Form/password_widget.html.php");
    }
}
