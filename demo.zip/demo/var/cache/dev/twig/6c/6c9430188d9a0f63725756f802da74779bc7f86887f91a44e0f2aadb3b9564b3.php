<?php

/* @Twig/Exception/exception.json.twig */
class __TwigTemplate_6b907452b1bb668803cd7ead5c84caf7ac28fb15c9d213b8d6cbea0511bdc6fd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_16c7eb61dff624cca0f3db13ee2afc44b0d1e0e7f684659062644c37427b8ab7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_16c7eb61dff624cca0f3db13ee2afc44b0d1e0e7f684659062644c37427b8ab7->enter($__internal_16c7eb61dff624cca0f3db13ee2afc44b0d1e0e7f684659062644c37427b8ab7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.json.twig"));

        $__internal_c1be7aca397204b5d54b0e6d689d0fd79054ca4a58cb47886d24e3341ce40e5c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c1be7aca397204b5d54b0e6d689d0fd79054ca4a58cb47886d24e3341ce40e5c->enter($__internal_c1be7aca397204b5d54b0e6d689d0fd79054ca4a58cb47886d24e3341ce40e5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.json.twig"));

        // line 1
        echo json_encode(array("error" => array("code" => (isset($context["status_code"]) || array_key_exists("status_code", $context) ? $context["status_code"] : (function () { throw new Twig_Error_Runtime('Variable "status_code" does not exist.', 1, $this->getSourceContext()); })()), "message" => (isset($context["status_text"]) || array_key_exists("status_text", $context) ? $context["status_text"] : (function () { throw new Twig_Error_Runtime('Variable "status_text" does not exist.', 1, $this->getSourceContext()); })()), "exception" => twig_get_attribute($this->env, $this->getSourceContext(), (isset($context["exception"]) || array_key_exists("exception", $context) ? $context["exception"] : (function () { throw new Twig_Error_Runtime('Variable "exception" does not exist.', 1, $this->getSourceContext()); })()), "toarray", array()))));
        echo "
";
        
        $__internal_16c7eb61dff624cca0f3db13ee2afc44b0d1e0e7f684659062644c37427b8ab7->leave($__internal_16c7eb61dff624cca0f3db13ee2afc44b0d1e0e7f684659062644c37427b8ab7_prof);

        
        $__internal_c1be7aca397204b5d54b0e6d689d0fd79054ca4a58cb47886d24e3341ce40e5c->leave($__internal_c1be7aca397204b5d54b0e6d689d0fd79054ca4a58cb47886d24e3341ce40e5c_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}
", "@Twig/Exception/exception.json.twig", "/Users/admin/Desktop/Work/Jonathan/demo/vendor/symfony/twig-bundle/Resources/views/Exception/exception.json.twig");
    }
}
